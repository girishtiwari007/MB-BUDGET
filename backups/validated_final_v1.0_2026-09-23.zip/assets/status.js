(function(){
  const DATA = window.BudgetPeriods.build(window.CURRENT_PAYLOAD || {}, window.REPORTS_DATA || {},
    window.BudgetPeriods.period(window.CURRENT_PAYLOAD_META?.completedMonth || "AUG 2026"));
  const META = window.CURRENT_PAYLOAD_META || {};
  const REPORTS = window.REPORTS_DATA || {};
  const SOURCES = window.YEAR_DATA_SOURCES || {};
  const $ = id => document.getElementById(id);
  const fmt = n => Number(n || 0).toLocaleString("en-IN", {maximumFractionDigits:0});
  const crore = n => (Number(n || 0) / 10000).toLocaleString("en-IN", {minimumFractionDigits:2, maximumFractionDigits:2});
  const rows = key => DATA[key]?.rows || [];
  const detailRows = list => (list || []).filter(row => String(row.Name || row.PU || row.Demand || "").toLowerCase() !== "total");
  const totalRow = key => rows(key).find(row => String(row.Name || "").toLowerCase() === "total") || {};
  const suspenseRows = list => detailRows(list).filter(row => /\b(12N|10N)\b/i.test(row.Name || "") || /suspense/i.test(row.Department || ""));
  const importantPuRows = list => detailRows(list).filter(row => /PU\s*-\s*(27|28|30|32|60)\b/i.test(row.Name || ""));
  const latestYear = (REPORTS.years || []).at(-1)?.fy || "2026-27";
  const previousYear = (REPORTS.years || []).at(-2)?.fy || "2025-26";
  const completedLabel = META.completedMonth || "AUG 2026";
  const runningLabel = META.runningMonth || "SEP 2026";
  const basisSource = META.basisSource || "auto-sensed from uploaded file";
  const SCRIPT_TOKEN = (() => {
    const scripts = Array.from(document.scripts || []);
    const self = scripts.find(script => /assets\/status\.js/i.test(script.src || ""));
    const match = self?.src?.match(/[?&]v=([^&]+)/);
    return match ? match[1] : String(META.updatedAt || META.statusAsOn || Date.now()).replace(/\W+/g, "");
  })();
  const mode = ["localhost","127.0.0.1"].includes(location.hostname) ? "Local admin mode" : "GitHub / static view";
  $("modePill").textContent = mode;

  function card(label, value, note){
    return `<article class="card"><span>${label}</span><strong>${value}</strong><em>${note || ""}</em></article>`;
  }
  function moneyPair(value){ return `${fmt(value)} | Cr ${crore(value)}`; }
  function freshHref(href){
    return /\.(pptx|xlsx|pdf)$/i.test(href) ? `${href}?v=${encodeURIComponent(SCRIPT_TOKEN)}` : href;
  }
  function esc(value){
    return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
  }
  function dateText(value){
    if (!value) return "Not recorded";
    return new Date(String(value).includes("T") ? value : `${value}T00:00:00`).toLocaleString("en-IN");
  }
  function renderSummary(manifest, exportManifest){
    const sourceCount = Object.keys(SOURCES.sources || {}).length;
    const currentTotal = totalRow("demand");
    $("summaryCards").innerHTML = [
      card("Portal Mode", mode, mode.includes("Local") ? "Upload and backup APIs should be available." : "Upload/backup actions need local server."),
      card("Data Basis", completedLabel, `Completed actual basis. ${runningLabel} remains running/till-date.`),
      card("Current Demand AE", moneyPair(currentTotal.AE), `${latestYear}; main total excludes 12N / 10N.`),
      card("FR Data As On", dateText(manifest?.dataAsOn || manifest?.uploadedAt), manifest?.originalName ? `${manifest.originalName}; stored ${dateText(manifest.uploadedAt)}` : "FR manifest not available"),
      card("Exports Refreshed", dateText(exportManifest?.refreshedAt), exportManifest?.status === "success" ? `OK; trigger ${exportManifest.trigger || "unknown"}` : "Run local sync/upload to refresh export package.")
    ].join("");
    if(sourceCount) $("summaryCards").insertAdjacentHTML("beforeend", card("Year Sources", sourceCount, `${previousYear} previous and ${latestYear} current mappings loaded.`));
  }
  function renderTables(){
    const items = [
      ["Demand / SMH Current", "demand"],
      ["PU Staff Current", "staff"],
      ["PU Non-Staff Current", "nonstaff"],
      ["PU Previous Comparison", "pu_prev"],
      ["Demand Previous Comparison", "demand_prev"]
    ];
    $("tableHealth").innerHTML = `<table class="health-table"><thead><tr><th>Table</th><th>Rows</th><th>OBA / RG</th><th>BP</th><th>AE</th><th>Important PU</th><th>Suspense</th><th>Status</th></tr></thead><tbody>${items.map(([label,key])=>{
      const list = rows(key);
      const total = totalRow(key);
      const ae = total.AE ?? total.AECurrent ?? 0;
      const oba = total.OBA ?? total.PreviousOBA ?? 0;
      const status = list.length ? "OK" : "Missing";
      return `<tr><td>${label}</td><td>${detailRows(list).length}</td><td>${moneyPair(oba)}</td><td>${moneyPair(total.BP || total.PreviousBP || 0)}</td><td>${moneyPair(ae)}</td><td>${importantPuRows(list).length}</td><td>${suspenseRows(list).length}</td><td class="${status==="OK"?"ok":"bad"}">${status}</td></tr>`;
    }).join("")}</tbody></table>`;
  }
  function renderAttention(manifest){
    const demandSuspense = suspenseRows(rows("demand"));
    const nonstaffTotal = totalRow("nonstaff");
    const pu98 = detailRows(rows("nonstaff")).find(row => /^PU\s*-\s*98\b/i.test(row.Name || ""));
    const issues = [
      {tone:"warn", title:"Completed month rule", text:`Default report basis is ${completedLabel}; running ${runningLabel} data must remain in Till Date / Running Month views.`},
      {tone:"bad", title:"Demand 12N / 10N separate", text:`${demandSuspense.length} suspense row(s) detected and should stay outside main demand total.`},
      pu98 ? {tone:"bad", title:"PU - 98 Credit / Recoveries", text:`Remaining balance ${moneyPair(pu98.Remaining)}. Review separately due negative/recovery behavior.`} : null,
      {tone:"warn", title:"Important PU focus", text:`${importantPuRows(rows("nonstaff")).length} important non-staff PU rows detected: 27, 28, 30, 32, 60.`},
      manifest?.backups?.length ? {tone:"", title:"FR backup copies", text:`${manifest.backups.length} backup folder(s) listed in FR manifest.`} : {tone:"warn", title:"FR backup copies", text:"No FR backup copy is listed yet in the repository manifest."}
    ].filter(Boolean);
    $("attentionList").innerHTML = `<div class="list">${issues.map(item=>`<div class="item ${item.tone}"><strong>${item.title}</strong><span>${item.text}</span></div>`).join("")}</div>`;
  }
  function renderExports(){
    const exports = [
      ["Current / Previous PPTX", "../exports/Moradabad_Division_Current_Year_Budget_Analysis.pptx"],
      ["DRM Existing Current-Year PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis.pptx"],
      ["DRM H Till Actual Month PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Till_Actual_Month.pptx"],
      ["DRM Full Previous-Year PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Full_FY_2025_26_Actual.pptx"],
      ["DRM Yearly Comparison PPTX", "../exports/Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx"],
      ["DRM Excel", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis.xlsx"],
      ["Current / Previous Excel", "../exports/Current_Previous_Year_PU_Demand_Analysis.xlsx"],
      ["FR Budget Excel", "../exports/FR_Budget_Status.xlsx"],
      ["Current / Previous PDF", "../exports/Current_Previous_Year_PU_Demand_Analysis.pdf"],
      ["SMH PU / Department Matrix PDF", "../exports/SMH_PU_Department_Wise_Matrix_Report.pdf"],
      ["FR Budget PDF", "../exports/FR_Budget_Status.pdf"]
    ];
    $("exportHealth").innerHTML = `<div class="export-grid">${exports.map(([label,href])=>`<div class="export-row"><a href="${freshHref(href)}" download>${label}</a><span>${href.split("/").pop()}</span></div>`).join("")}</div>`;
  }
  function reviewPackText(){
    return [
      "MB Budget Authority Review Pack",
      "",
      `GUI synced basis: Completed actuals up to ${completedLabel}.`,
      `Basis source: ${basisSource}.`,
      `Running month: ${runningLabel} data should be reviewed only in Till Date / Running Month views.`,
      "Attention: Important PU 27, 28, 30, 32 and 60 should be checked separately.",
      "Suspense: Demand 12N / 10N remains separate and excluded from normal demand totals.",
      "",
      "Before sharing:",
      "- Confirm Data Basis and FR Data As On cards.",
      "- Confirm export refresh status is OK.",
      "- Open at least one .xlsx, one PDF and one PPTX after local sync.",
      "- Use Data Export Centre only for final downloads."
    ].join("\n");
  }
  function renderReviewPack(){
    const items = [
      ["Current Review", "Check Current / Previous PDF, Excel and PPTX against visible portal basis."],
      ["DRM Review", "Use editable DRM PPTX and Excel package for presentation work."],
      ["FR Review", "Confirm FR PDF and .xlsx reflect latest FR upload/date stamp."],
      ["Audit Checks", "Confirm Demand 12N / 10N, important PU rows and completed/running month handling."]
    ];
    $("reviewPack").innerHTML = items.map(([title, text]) => `<article class="pack-card"><strong>${esc(title)}</strong><span>${esc(text)}</span></article>`).join("");
    $("reviewPackText").textContent = reviewPackText();
  }
  function renderRefreshProof(exportManifest){
    const host = $("refreshProof");
    if (!host) return;
    if (!exportManifest) {
      host.innerHTML = `<div class="panel-head"><h2>Export Refresh</h2><span>Run local sync/upload once to generate the export refresh manifest.</span></div><div class="item warn"><strong>Manifest not found</strong><span>Export package cannot be confirmed from repository metadata.</span></div>`;
      return;
    }
    const missing = exportManifest.missing?.length ? `Missing: ${exportManifest.missing.join(", ")}` : "All expected export files present.";
    const tone = exportManifest.status === "success" ? "ok" : "warn";
    host.innerHTML = `<div class="panel-head"><h2>Export Refresh</h2><span>${esc(new Date(exportManifest.refreshedAt).toLocaleString("en-IN"))}</span></div><div class="item ${tone === "ok" ? "" : "warn"}"><strong>${esc(exportManifest.status === "success" ? "Exports Refreshed" : "Export Refresh Needs Review")}</strong><span>Trigger: ${esc(exportManifest.trigger || "unknown")}. ${esc(missing)}</span></div>`;
  }
  function statusFor(file, modified){
    if (!modified) return "Check";
    const ageDays = (Date.now() - modified.getTime()) / 86400000;
    return ageDays > 14 ? "Old" : "Fresh";
  }
  async function headInfo(href){
    try {
      const response = await fetch(freshHref(href), { method: "HEAD", cache: "no-store" });
      if (!response.ok) return { exists: false, modified: null };
      const raw = response.headers.get("Last-Modified");
      return { exists: true, modified: raw ? new Date(raw) : null };
    } catch (_error) {
      return { exists: null, modified: null };
    }
  }
  async function renderFreshness(){
    const exports = [
      ["Current / Previous PDF", "../exports/Current_Previous_Year_PU_Demand_Analysis.pdf", "PDF", `Completed ${completedLabel}`],
      ["SMH Matrix PDF", "../exports/SMH_PU_Department_Wise_Matrix_Report.pdf", "PDF", `PU and Department ACT / BUD PROP / VAR up to ${completedLabel}`],
      ["Current / Previous Excel", "../exports/Current_Previous_Year_PU_Demand_Analysis.xlsx", "XLSX", `Completed ${completedLabel}`],
      ["Current / Previous PPTX", "../exports/Moradabad_Division_Current_Year_Budget_Analysis.pptx", "PPTX", `Completed ${completedLabel}`],
      ["DRM Existing Current-Year PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis.pptx", "PPTX", `Completed ${completedLabel} + H full FY 2025-26`],
      ["DRM H Till Actual Month PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Till_Actual_Month.pptx", "PPTX", `Completed ${completedLabel} + H up to ${completedLabel.replace("2026", "2025")}`],
      ["DRM Full Previous-Year PPTX", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Full_FY_2025_26_Actual.pptx", "PPTX", `Completed ${completedLabel} + H full FY 2025-26`],
      ["DRM Yearly Comparison PPTX", "../exports/Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx", "PPTX", "Yearly comparison"],
      ["DRM Excel", "../exports/Moradabad_Division_DRM_Budget_FR_Analysis.xlsx", "XLSX", `Completed ${completedLabel}`],
      ["FR Budget PDF", "../exports/FR_Budget_Status.pdf", "PDF", "FR as uploaded"],
      ["FR Budget Excel", "../exports/FR_Budget_Status.xlsx", "XLSX", "FR as uploaded"]
    ];
    const rows = await Promise.all(exports.map(async file => {
      const info = await headInfo(file[1]);
      const status = info.exists === false ? "Missing" : statusFor(file, info.modified);
      const modified = info.modified ? info.modified.toLocaleString("en-IN") : (info.exists === null ? "Open via local/server to check" : "Not available");
      return { file, status, modified };
    }));
    $("freshnessStamp").textContent = `Checked ${new Date().toLocaleString("en-IN")}`;
    $("freshnessTable").innerHTML = `<table><thead><tr><th>Export</th><th>Type</th><th>Basis</th><th>Last Modified</th><th>Status</th></tr></thead><tbody>${rows.map(({file, status, modified}) => `<tr class="${status.toLowerCase()}"><td><a href="${esc(freshHref(file[1]))}" download>${esc(file[0])}</a></td><td>${esc(file[2])}</td><td>${esc(file[3])}</td><td>${esc(modified)}</td><td>${esc(status)}</td></tr>`).join("")}</tbody></table>`;
  }
  async function loadManifest(){
    try{
      const response = await fetch("../data/fr/fr-upload-manifest.json?ts=" + Date.now());
      return response.ok ? await response.json() : null;
    }catch{ return null; }
  }
  async function loadExportManifest(){
    try{
      const response = await fetch("../data/export-refresh-manifest.json?ts=" + Date.now());
      return response.ok ? await response.json() : null;
    }catch{ return null; }
  }
  Promise.all([loadManifest(), loadExportManifest()]).then(([manifest, exportManifest]) => {
    renderSummary(manifest, exportManifest);
    renderTables();
    renderAttention(manifest);
    renderExports();
    renderRefreshProof(exportManifest);
    renderReviewPack();
    renderFreshness();
  });
  $("copyReviewPack")?.addEventListener("click", async () => {
    const text = reviewPackText();
    $("reviewPackText").textContent = text;
    try {
      await navigator.clipboard.writeText(text);
      $("reviewPackText").textContent = `${text}\n\nCopied review pack summary to clipboard.`;
    } catch (_error) {
      $("reviewPackText").textContent = `${text}\n\nClipboard copy was blocked. Select this text and copy manually.`;
    }
  });
})();
