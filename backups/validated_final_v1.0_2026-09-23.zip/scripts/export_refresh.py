from datetime import datetime
from pathlib import Path
import json
import posixpath
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile


REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST = REPO_ROOT / "data" / "export-refresh-manifest.json"
GENERATOR = REPO_ROOT / "scripts" / "generate_drm_exports.py"
EXPECTED_EXPORTS = [
    "exports/Current_Previous_Year_PU_Demand_Analysis.xlsx",
    "exports/Current_Previous_Year_PU_Demand_Analysis.pdf",
    "exports/SMH_PU_Department_Wise_Matrix_Report.pdf",
    "exports/FR_Budget_Status.xlsx",
    "exports/FR_Budget_Status.pdf",
    "exports/Moradabad_Division_Current_Year_Budget_Analysis.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis.xlsx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Till_Actual_Month.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Full_FY_2025_26_Actual.pptx",
    "exports/Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx",
]
HTML_TARGETS = [
    "index.html",
    "pages/admin.html",
    "pages/ai-insight.html",
    "pages/current.html",
    "pages/exports.html",
    "pages/fr.html",
    "pages/logic.html",
    "pages/reports.html",
    "pages/status.html",
    "pages/yearly-review.html",
]
VIEW_EXPORT_TARGETS = [
    "pages/ai-insight.html",
    "pages/current.html",
    "pages/exports.html",
    "pages/fr.html",
    "pages/reports.html",
    "pages/status.html",
    "pages/yearly-review.html",
]
VIEW_EXPORT_ASSETS = [
    "assets/view-export.css",
    "assets/view-export.js",
]
OFFICE_SUFFIXES = {".xlsx", ".pptx"}
PDF_SUFFIXES = {".pdf"}
BASIS_EXPORTS = [
    "exports/Current_Previous_Year_PU_Demand_Analysis.xlsx",
    "exports/Current_Previous_Year_PU_Demand_Analysis.pdf",
    "exports/SMH_PU_Department_Wise_Matrix_Report.pdf",
    "exports/Moradabad_Division_Current_Year_Budget_Analysis.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis.xlsx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Till_Actual_Month.pptx",
    "exports/Moradabad_Division_DRM_Budget_FR_Analysis_H_Full_FY_2025_26_Actual.pptx",
    "exports/Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx",
]
YEARLY_COMPARISON_EXPORT = "exports/Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx"
YEARLY_COMPARISON_TEMPLATE = "data/templates/Moradabad_Division_DRM_Yearly_Comparison_Template.pptx"


def refresh_portal_asset_versions(token=None):
    token = token or datetime.now().strftime("%Y%m%d%H%M%S")
    targets = [REPO_ROOT / "index.html", *sorted((REPO_ROOT / "pages").glob("*.html"))]
    pattern = re.compile(r'((?:src|href)="(?!(?:https?:|mailto:|#))[^"]+\?v=)[^"]+(")')
    changed_files = []
    for path in targets:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        updated, count = pattern.subn(rf"\g<1>{token}\2", text)
        if count and updated != text:
            path.write_text(updated, encoding="utf-8")
            changed_files.append(path.relative_to(REPO_ROOT).as_posix())
    return {"token": token, "files": changed_files}


def export_file_info(relative_path):
    path = REPO_ROOT / relative_path
    return {
        "path": relative_path,
        "exists": path.exists(),
        "size": path.stat().st_size if path.exists() else 0,
        "modifiedAt": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds") if path.exists() else "",
    }


def current_payload_meta():
    path = REPO_ROOT / "data" / "current_payload.js"
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    match = re.search(r"window\.CURRENT_PAYLOAD_META\s*=\s*(\{.*?\});", text, flags=re.S)
    return json.loads(match.group(1)) if match else {}


def validate_current_basis():
    errors = []
    upload_manifest = REPO_ROOT / "data" / "source-files" / "2026-2027" / "upload-manifest.json"
    meta = current_payload_meta()
    if not upload_manifest.exists():
        errors.append("Current-year upload manifest is missing.")
        return errors
    upload = json.loads(upload_manifest.read_text(encoding="utf-8"))
    for key in ("completedMonth", "runningMonth", "statusAsOn"):
        if upload.get(key) and meta.get(key) and upload.get(key) != meta.get(key):
            errors.append(f"Current payload {key} does not match upload manifest: {meta.get(key)} != {upload.get(key)}")
    return errors


def office_text(path):
    chunks = []
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if name.endswith(".xml"):
                chunks.append(archive.read(name).decode("utf-8", errors="ignore"))
    return "\n".join(chunks)


def export_text(path):
    suffix = path.suffix.lower()
    if suffix in OFFICE_SUFFIXES:
        return office_text(path)
    if suffix in PDF_SUFFIXES:
        return path.read_bytes().decode("latin-1", errors="ignore")
    return path.read_text(encoding="utf-8", errors="ignore")


def validate_basis_export_content():
    errors = []
    meta = current_payload_meta()
    completed = str(meta.get("completedMonth") or "").strip().upper()
    if not completed:
        errors.append("Completed month is missing from current payload meta.")
        return errors
    for rel in BASIS_EXPORTS:
        path = REPO_ROOT / rel
        if not path.exists():
            continue
        text = export_text(path).upper()
        if completed not in text:
            errors.append(f"{rel} does not contain completed-month basis {completed}.")
        if "COMPLETED MONTH PROJECTION" in text:
            errors.append(f"{rel} still contains old projection wording.")
        if completed != "JUL 2026" and "JUL 2026" in text:
            errors.append(f"{rel} still contains stale JUL 2026 basis text.")
    return errors


def pptx_part_counts(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        return {
            "slides": len([name for name in names if re.match(r"ppt/slides/slide\d+\.xml$", name)]),
            "charts": len([name for name in names if re.match(r"ppt/charts/chart\d+\.xml$", name)]),
            "relationships": len([name for name in names if name.endswith(".rels")]),
        }


def validate_yearly_comparison_template():
    errors = []
    export_path = REPO_ROOT / YEARLY_COMPARISON_EXPORT
    template_path = REPO_ROOT / YEARLY_COMPARISON_TEMPLATE
    if not export_path.exists():
        return [f"Yearly Comparison export missing: {YEARLY_COMPARISON_EXPORT}"], {}
    if not template_path.exists():
        return [f"Yearly Comparison template missing: {YEARLY_COMPARISON_TEMPLATE}"], {}
    template_counts = pptx_part_counts(template_path)
    export_counts = pptx_part_counts(export_path)
    for key in ("slides", "charts", "relationships"):
        if export_counts[key] != template_counts[key]:
            errors.append(
                f"Yearly Comparison PPTX template structure changed: {key} {export_counts[key]} != template {template_counts[key]}"
            )
    text = export_text(export_path).upper()
    completed = str(current_payload_meta().get("completedMonth") or "").strip().upper()
    if completed and f"THROUGH {completed}" not in text:
        errors.append(f"Yearly Comparison PPTX title does not show through {completed}.")
    if "NATIVE POWERPOINT CHARTS WITH EMBEDDED EDITABLE DATA" not in text:
        errors.append("Yearly Comparison PPTX lost the template editable-chart label.")
    return errors, {"template": template_counts, "export": export_counts}


def validate_html_cache_token(token):
    errors = []
    if not token:
        errors.append("HTML cache refresh token missing.")
        return errors
    version_pattern = re.compile(r'(?:src|href)="(?!(?:https?:|mailto:|#))[^"]+\?v=([^"]+)"')
    for rel in HTML_TARGETS:
        path = REPO_ROOT / rel
        if not path.exists():
            errors.append(f"HTML page missing: {rel}")
            continue
        tokens = version_pattern.findall(path.read_text(encoding="utf-8"))
        stale = sorted({found for found in tokens if found != token})
        if stale:
            errors.append(f"{rel} has stale asset/data cache tokens: {', '.join(stale[:4])}")
    return errors


def validate_view_export_wiring():
    errors = []
    for rel in VIEW_EXPORT_ASSETS:
        path = REPO_ROOT / rel
        if not path.exists() or path.stat().st_size <= 0:
            errors.append(f"View export asset missing or empty: {rel}")
    script_path = REPO_ROOT / "assets" / "view-export.js"
    if script_path.exists():
        script = script_path.read_text(encoding="utf-8")
        for required in ("exportViewExcel", "exportViewPdf", "exportViewPpt", "currentViewSheets", "printPdf", "exportPpt"):
            if required not in script:
                errors.append(f"View export script missing {required}.")
    protection = (REPO_ROOT / "assets" / "protection.js").read_text(encoding="utf-8") if (REPO_ROOT / "assets" / "protection.js").exists() else ""
    for required in ("#exportViewExcel", "#exportViewPdf", "#exportViewPpt", ".view-export"):
        if required not in protection:
            errors.append(f"Export protection does not lock {required}.")
    for rel in VIEW_EXPORT_TARGETS:
        path = REPO_ROOT / rel
        if not path.exists():
            errors.append(f"View export page missing: {rel}")
            continue
        text = path.read_text(encoding="utf-8")
        for asset in ("view-export.css", "view-export.js"):
            if asset not in text:
                errors.append(f"{rel} does not include {asset}.")
    return errors


def validate_export_file(path, run_started):
    errors = []
    if not path.exists() or path.stat().st_size <= 0:
        return [f"Export missing or empty: {path.relative_to(REPO_ROOT).as_posix()}"]
    if path.stat().st_mtime + 2 < run_started.timestamp():
        errors.append(f"Export is older than this refresh run: {path.relative_to(REPO_ROOT).as_posix()}")
    if path.suffix.lower() in OFFICE_SUFFIXES:
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
        if bad:
            errors.append(f"Office export is corrupt: {path.name} -> {bad}")
        errors.extend(validate_office_package(path))
    elif path.suffix.lower() in PDF_SUFFIXES and not path.read_bytes().startswith(b"%PDF"):
        errors.append(f"PDF export has invalid header: {path.name}")
    return errors


def relationship_base(rel_name):
    if rel_name == "_rels/.rels":
        return ""
    if "/_rels/" not in rel_name:
        return ""
    return rel_name.split("/_rels/", 1)[0] + "/"


def validate_office_package(path):
    errors = []
    rel_ns = "{http://schemas.openxmlformats.org/package/2006/relationships}"
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        for name in names:
            if not (name.endswith(".xml") or name.endswith(".rels")):
                continue
            try:
                root = ET.fromstring(archive.read(name))
            except Exception as exc:
                errors.append(f"Office XML part is invalid: {path.name}:{name}: {exc}")
                continue
            if not name.endswith(".rels"):
                continue
            ids = []
            base = relationship_base(name)
            for rel in root.findall(f"{rel_ns}Relationship"):
                rel_id = rel.attrib.get("Id", "")
                target = rel.attrib.get("Target", "")
                mode = rel.attrib.get("TargetMode", "")
                ids.append(rel_id)
                if mode == "External" or not target or re.match(r"^[a-z]+:", target, re.I):
                    continue
                resolved = posixpath.normpath(posixpath.join(base, target)).lstrip("/")
                if resolved not in names:
                    errors.append(f"Office relationship target missing: {path.name}:{name}:{rel_id}->{target}")
            duplicates = sorted({rel_id for rel_id in ids if ids.count(rel_id) > 1})
            if duplicates:
                errors.append(f"Office relationship has duplicate ids: {path.name}:{name}:{', '.join(duplicates)}")
    return errors


def smoke_test_manifest(payload, run_started):
    errors = []
    yearly_errors, yearly_structure = validate_yearly_comparison_template()
    errors.extend(yearly_errors)
    errors.extend(payload.get("missing") or [])
    for rel in EXPECTED_EXPORTS:
        errors.extend(validate_export_file(REPO_ROOT / rel, run_started))
    errors.extend(validate_html_cache_token((payload.get("cacheRefresh") or {}).get("token")))
    errors.extend(validate_view_export_wiring())
    errors.extend(validate_current_basis())
    errors.extend(validate_basis_export_content())
    payload["smokeTest"] = {
        "status": "failed" if errors else "success",
        "checkedAt": datetime.now().isoformat(timespec="seconds"),
        "checkedExports": len(EXPECTED_EXPORTS),
        "checkedPages": len(HTML_TARGETS),
        "checkedViewExportPages": len(VIEW_EXPORT_TARGETS),
        "yearlyComparisonTemplate": yearly_structure,
        "errors": errors,
    }
    MANIFEST.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    if errors:
        raise RuntimeError("Export refresh smoke test failed:\n- " + "\n- ".join(errors))
    return payload


def write_manifest(trigger, output, cache_refresh=None, run_started=None):
    files = [export_file_info(path) for path in EXPECTED_EXPORTS]
    missing = [item["path"] for item in files if not item["exists"] or item["size"] <= 0]
    payload = {
        "refreshedAt": datetime.now().isoformat(timespec="seconds"),
        "runStartedAt": (run_started or datetime.now()).isoformat(timespec="seconds"),
        "trigger": trigger,
        "status": "success" if not missing else "incomplete",
        "missing": missing,
        "files": files,
        "generator": GENERATOR.relative_to(REPO_ROOT).as_posix(),
        "output": output.strip(),
        "cacheRefresh": cache_refresh or {},
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    if missing:
        raise RuntimeError("Export refresh incomplete. Missing: " + ", ".join(missing))
    return payload


def refresh_exports(trigger="manual"):
    if not GENERATOR.exists():
        raise RuntimeError(f"Export generator not found: {GENERATOR}")
    run_started = datetime.now()
    result = subprocess.run([sys.executable, str(GENERATOR)], cwd=REPO_ROOT, text=True, capture_output=True)
    output = "\n".join(part for part in [result.stdout.strip(), result.stderr.strip()] if part)
    if result.returncode:
        write_manifest(f"{trigger}:failed", output)
        raise RuntimeError(output or "Export refresh failed")
    cache_refresh = refresh_portal_asset_versions()
    manifest = write_manifest(trigger, output, cache_refresh, run_started)
    smoke_test_manifest(manifest, run_started)
    return output or f"Exports refreshed: {manifest['refreshedAt']}"

def main():
    trigger = sys.argv[1] if len(sys.argv) > 1 else "manual-cli"
    try:
        print(refresh_exports(trigger))
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()

