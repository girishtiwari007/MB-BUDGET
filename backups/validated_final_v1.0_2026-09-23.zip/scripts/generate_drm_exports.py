import json
import re
import shutil
import zipfile
from copy import deepcopy
from html import escape, unescape
from pathlib import Path
from xml.sax.saxutils import escape as xesc

import xlrd
from openpyxl import Workbook, load_workbook
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "exports"
CURRENT_XLSX = OUT / "Current_Previous_Year_PU_Demand_Analysis.xlsx"
CURRENT_PDF = OUT / "Current_Previous_Year_PU_Demand_Analysis.pdf"
FR_XLSX = OUT / "FR_Budget_Status.xlsx"
FR_PDF = OUT / "FR_Budget_Status.pdf"
SMH_MATRIX_PDF = OUT / "SMH_PU_Department_Wise_Matrix_Report.pdf"
CURRENT_PPTX = OUT / "Moradabad_Division_Current_Year_Budget_Analysis.pptx"
PPTX = OUT / "Moradabad_Division_DRM_Budget_FR_Analysis.pptx"
DRM_TILL_ACTUAL_PPTX = OUT / "Moradabad_Division_DRM_Budget_FR_Analysis_H_Till_Actual_Month.pptx"
DRM_FULL_PREVIOUS_PPTX = OUT / "Moradabad_Division_DRM_Budget_FR_Analysis_H_Full_FY_2025_26_Actual.pptx"
DRM_YEARLY_COMPARISON_PPTX = OUT / "Moradabad_Division_DRM_PPT_With_Yearly_Comparison.pptx"
XLSX = OUT / "Moradabad_Division_DRM_Budget_FR_Analysis.xlsx"
PREVIOUS_FR_XLSX = ROOT / "data" / "source-files" / "2025-2026" / "fr-budget-status.xlsx"
YEARLY_COMPARISON_TEMPLATE = ROOT / "data" / "templates" / "Moradabad_Division_DRM_Yearly_Comparison_Template.pptx"
TEMPLATE_CANDIDATES = [
    ROOT / "data" / "templates" / "Moradabad_Division_DRM_Table_Template.pptx",
    Path(r"C:\Users\HP\Dropbox\Revenue PU Laibilities\PPT PORTAL\Moradabad Division Quarty FR and Revenue Budget Analysis DRM.pptx"),
    Path(r"C:\Users\HP\Dropbox\Revenue PU Laibilities\PPT PORTAL\Moradabad Division Quarty FR and Revenue Budget Analysis DRM JULY.pptx"),
    Path(r"C:\Users\HP\Dropbox\Revenue PU Laibilities\PPT PORTAL\Moradabad Division Quarty FR and Revenue Budget Analysis DRM JUN.pptx"),
    Path(r"C:\Users\HP\Dropbox\Revenue PU Laibilities\PPT PORTAL\Moradabad Division Quarty FR and Revenue Budget Analysis.pptx"),
]
TEMPLATE_PPTX = next((path for path in TEMPLATE_CANDIDATES if path.exists()), TEMPLATE_CANDIDATES[0])
SLIDE_W, SLIDE_H = 12192000, 6858000
BLUE = "1F4E79"
NAVY = "003366"
LIGHT = "E8F2F8"
YELLOW = "FFF2CC"
WHITE = "FFFFFF"
BLACK = "000000"
GREEN = "25A55B"
AMBER = "F2C230"
RED = "D92323"
TEAL = "006F78"
GREEN_LIGHT = "DFF3E7"
AMBER_LIGHT = "FFF2CC"
RED_LIGHT = "FCE4E4"
SMH_COLUMNS = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "10N", "11"]


def load_json_assignment(path, name):
    text = path.read_text(encoding="utf-8")
    match = re.search(rf"{re.escape(name)}\s*=\s*(.*?);?\s*$", text, re.S)
    if not match:
        raise RuntimeError(f"Cannot locate {name} in {path}")
    return json.loads(match.group(1))


def load_fr_data():
    text = (ROOT / "pages" / "fr.html").read_text(encoding="utf-8")
    match = re.search(r"const\s+workbookData\s*=\s*(\[.*?\]);\s*const\s+funds", text, re.S)
    if not match:
        raise RuntimeError("Cannot locate FR workbookData")
    return json.loads(match.group(1))


def load_fr_as_on():
    text = (ROOT / "pages" / "fr.html").read_text(encoding="utf-8")
    match = re.search(r"Data as on <strong>(.*?)</strong>", text)
    return clean_text(match.group(1)) if match else "FR as uploaded"


def current_as_on_label():
    meta = load_current_meta()
    return f"{meta.get('completedMonth', 'Completed month')} | uploaded {meta.get('statusAsOn', '')}"


def load_current_meta():
    text = (ROOT / "data" / "current_payload.js").read_text(encoding="utf-8")
    match = re.search(r"window\.CURRENT_PAYLOAD_META\s*=\s*(\{.*?\});", text, re.S)
    return json.loads(match.group(1)) if match else {}


def period_from_meta():
    meta = load_current_meta()
    label = str(meta.get("completedMonth") or "AUG 2026").strip().upper()
    match = re.search(r"([A-Z]{3})\s+(20\d{2})", label)
    month = match.group(1) if match else label[:3]
    year = int(match.group(2)) if match else 2026
    months = ["APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR"]
    count = months.index(month) + 1 if month in months else 4
    return {"month": month, "year": year, "count": count, "label": f"{month} {year}"}


def inr(value, decimals=0):
    try:
        n = float(value or 0)
    except Exception:
        return ""
    return f"{n:,.{decimals}f}" if decimals else f"{round(n):,}"


def money(value):
    try:
        n = float(value or 0)
    except Exception:
        n = 0
    return f"{inr(n)}\n{n / 10000:.2f} Cr"


def pct(value):
    try:
        return f"{round(float(value or 0))}"
    except Exception:
        return "0"


def row_name(row):
    return row.get("Name") or row.get("PU") or row.get("Demand") or ""


def is_total(row):
    return row_name(row).strip().lower() == "total"


def number_value(value):
    try:
        return float(value or 0)
    except Exception:
        return 0


def code_from_label(label, prefix):
    match = re.search(rf"{re.escape(prefix)}\s*-\s*([0-9A-Z]+)", str(label or ""), re.I)
    return match.group(1).upper() if match else ""


def demand_key(label):
    match = re.search(r"Demand\s+([0-9A-Z]+)", str(label or ""), re.I)
    return match.group(1).upper() if match else ""


def is_demand_suspense(row):
    name = row_name(row).upper()
    department = str(row.get("Department") or "").upper()
    return bool(re.search(r"\b(12N|10N)\b", name)) or "SUSPENSE" in department


def detail_rows(rows):
    return [row for row in rows or [] if not is_total(row)]


def normal_total_rows(rows):
    return [row for row in detail_rows(rows) if not is_demand_suspense(row)]


def demand_suspense_rows(rows):
    return [row for row in detail_rows(rows) if is_demand_suspense(row)]


def latest_report_year(reports, offset=0):
    years = reports.get("years") or []
    idx = max(0, len(years) - 1 - offset)
    return (years[idx] or {}).get("fy", "")


def match_monthly_key(scope, label, bucket):
    keys = list((bucket or {}).keys())
    if label in bucket:
        return label
    if scope == "pu":
        code = code_from_label(label, "PU")
        return next((key for key in keys if code_from_label(key, "PU") == code), "")
    if scope == "demand":
        demand = demand_key(label)
        smh_match = re.search(r"/\s*([0-9A-Z]+)", str(label or ""), re.I)
        smh = smh_match.group(1).upper() if smh_match else ""
        return next((key for key in keys if demand_key(key) == demand and (not smh or f"SMH {smh}" in key.upper())), "")
    return next((key for key in keys if key == label), "")


def month_actual(reports, scope, label, fy, count):
    bucket = ((reports.get("monthly") or {}).get(scope) or {})
    key = match_monthly_key(scope, label, bucket)
    values = (bucket.get(key) or {}).get(fy) if key else None
    if values is None and scope == "demand":
        demand = demand_key(label)
        smh_match = re.search(r"/\s*([0-9A-Z]+)", str(label or ""), re.I)
        smh = smh_match.group(1).upper() if smh_match else ""
        for candidate in bucket:
            candidate_values = (bucket.get(candidate) or {}).get(fy)
            if candidate_values is not None and demand_key(candidate) == demand and (not smh or f"SMH {smh}" in candidate.upper()):
                values = candidate_values
                break
    if not isinstance(values, list):
        return None
    return sum(number_value(value) for value in values[:count])


def relabel_period(text, month="JUN", year=2026, count=3):
    label = f"{month} {year}"
    return (str(text or "")
        .replace("JUL 2026", label)
        .replace("AUG 2026", label)
        .replace("JUL 2025", f"{month} 2025")
        .replace("AUG 2025", f"{month} 2025")
        .replace("/ 12 * 4", f"/ 12 * {count}")
        .replace("/ 12 * 5", f"/ 12 * {count}")
        .replace("BP UPTO JUL 2026", f"BP up to {label}")
        .replace("BP UPTO AUG 2026", f"BP up to {label}")
        .replace("Actuals Upto JUL 2026", f"Actuals up to {label}")
        .replace("Actuals Upto AUG 2026", f"Actuals up to {label}"))


def summary_row(label, oba, ae, months=3, bp_override=None):
    bp = number_value(bp_override) if bp_override is not None else oba / 12 * months
    return {
        "Name": label,
        "OBA": oba,
        "BP": bp,
        "AE": ae,
        "Variation": ae - bp,
        "BPPercent": ae / bp * 100 if bp else 0,
        "Remaining": oba - ae,
        "OBAPercent": ae / oba * 100 if oba else 0,
        "Months": months,
    }


def add_total(rows):
    normal = normal_total_rows(rows)
    suspense = demand_suspense_rows(rows)
    months = number_value((normal[0] if normal else rows[0] if rows else {}).get("Months") or 3)
    oba = sum(number_value(row.get("OBA")) for row in normal)
    ae = sum(number_value(row.get("AE")) for row in normal)
    bp = sum(number_value(row.get("BP")) for row in normal)
    return normal + [summary_row("Total", oba, ae, months, bp)] + suspense


def filtered_pu_rows(rows, codes):
    wanted = {str(code).zfill(2) for code in codes}
    detail = [row for row in detail_rows(rows) if code_from_label(row_name(row), "PU").zfill(2) in wanted]
    return add_total(detail)


def previous_actual_map(rows):
    return {row_name(row): number_value(row.get("AEPrevious")) for row in detail_rows(rows)}


def previous_final_actual_map(reports, scope, rows, fy="2025-26"):
    return {
        row_name(row): number_value(month_actual(reports, scope, row_name(row), fy, 12))
        for row in detail_rows(rows)
    }


def add_previous_actual_column(tab, rows, previous_actuals, header_prefix="H", label=None):
    columns = list(tab["columns"]) + [{
        "key": "PreviousYearActual",
        "label": label or f"{header_prefix}\nActual Final Expenditure\nFY 2025-26",
        "format": "money",
    }]
    next_rows = []
    for row in rows:
        next_row = dict(row)
        if is_total(next_row):
            total_source = normal_total_rows(next_rows)
            next_row["PreviousYearActual"] = sum(number_value(item.get("PreviousYearActual")) for item in total_source)
        else:
            next_row["PreviousYearActual"] = previous_actuals.get(row_name(next_row), 0)
        next_rows.append(next_row)
    return columns, next_rows


def resolve_node():
    candidates = [
        shutil.which("node"),
        ROOT / "node.exe",
        ROOT / "tools" / "node" / "node.exe",
        Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies" / "node" / "bin" / "node.exe",
        Path.home() / "AppData" / "Local" / "Programs" / "nodejs" / "node.exe",
        Path(r"C:\Program Files\nodejs\node.exe"),
        Path(r"C:\Program Files (x86)\nodejs\node.exe"),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.exists():
            return str(path)
    raise RuntimeError(
        "Node.js is required for the shared portal/export calculations. "
        "Install Node.js or keep the bundled Codex runtime at "
        r"C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
    )


def apply_completed_period(payload):
    # Share browser calculations so PDF/Excel/PPTX cannot drift from the portal.
    import subprocess
    node = resolve_node()
    result = subprocess.run([node, str(ROOT / "scripts" / "export-period-data.cjs")],
                            cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=True)
    return json.loads(result.stdout)


def utilization_class(value):
    try:
        v = float(value or 0)
    except Exception:
        v = 0
    if v < 0 or v > 100:
        return "red"
    if v >= 75:
        return "amber"
    return "green"


def utilization_fill(value, light=False):
    cls = utilization_class(value)
    if light:
        return {"green": GREEN_LIGHT, "amber": AMBER_LIGHT, "red": RED_LIGHT}.get(cls, GREEN_LIGHT)
    return {"green": GREEN, "amber": AMBER, "red": RED}.get(cls, GREEN)


def utilization_text_color(value):
    return BLACK if utilization_class(value) == "amber" else WHITE


def utilization_dot(value):
    return {"green": "G", "amber": "A", "red": "R"}.get(utilization_class(value), "G")


def display_cell(row, col):
    key, fmt = col["key"], col.get("format")
    val = row.get(key, "")
    if fmt == "money":
        return money(val)
    if key in ("BPPercent", "OBAPercent"):
        return pct(val)
    if fmt == "int":
        return pct(val)
    return str(val)


def table_from_payload(tab, columns=None, rows=None):
    columns = columns or tab["columns"]
    rows = rows or tab["rows"]
    headers = [c["label"] for c in columns]
    body = [[display_cell(r, c) for c in columns] for r in rows]
    return headers, body


def fr_report_table(sheet):
    headers = ["Plan Head", "Plan Head Name", "SBA 2026-27", "AE", "Variation (AE - SBA)", "% SBA"]
    body = []
    for rec in sheet["records"]:
        total = rec["funds"]["TOTAL"]
        body.append([
            rec.get("planHead") or "",
            rec.get("planName") or "",
            money(total["sba"]),
            money(total["ae"]),
            money(total["ae"] - total["sba"]),
            f"{total.get('spentPct', 0):.2f}",
        ])
    total = sheet["total"]["funds"]["TOTAL"]
    body.append([
        "Total",
        sheet["total"].get("planName") or "",
        money(total["sba"]),
        money(total["ae"]),
        money(total["ae"] - total["sba"]),
        f"{total.get('spentPct', 0):.2f}",
    ])
    return headers, body


def fr_fund_table(sheet):
    headers = ["Fund", "SBA", "AE", "Available", "Expensed %", "Remaining %"]
    body = []
    for fund, values in sheet["fundAnalysis"].items():
        body.append([fund, money(values["sba"]), money(values["ae"]), money(values["available"]), f"{values.get('spentPct',0):.2f}", f"{values.get('remainPct',0):.2f}"])
    return headers, body


def fr_previous_cr(value):
    return f"{number_value(value) / 10000:.2f} Cr"


def parse_previous_fr_sheet(ws):
    fund_columns = {}
    for col in range(1, min(ws.max_column, 80) + 1):
        fund = clean_text(ws.cell(2, col).value).strip().upper()
        metric = clean_text(ws.cell(3, col + 1).value).strip().upper() if col + 1 <= ws.max_column else ""
        if fund and metric == "AE":
            fund_columns[fund] = col
    rows = {}
    fund_totals = {}
    total_ae = 0
    for row_idx in range(4, ws.max_row + 1):
        raw_head = ws.cell(row_idx, 1).value
        label = clean_text(raw_head).strip()
        if not label:
            continue
        is_total_row = label.lower() == "total"
        plan_head = "Total" if is_total_row else str(raw_head).split(".")[0].strip()
        plan_name = clean_text(ws.cell(row_idx, 2).value).strip()
        if not is_total_row and not plan_head.isdigit() and not plan_name:
            continue
        funds = {}
        for fund, col in fund_columns.items():
            funds[fund] = {
                "sba": number_value(ws.cell(row_idx, col).value),
                "ae": number_value(ws.cell(row_idx, col + 1).value),
            }
        if is_total_row:
            fund_totals = funds
            total_ae = number_value((funds.get("TOTAL") or {}).get("ae"))
        else:
            rows[plan_head if plan_head.isdigit() else plan_name.upper()] = funds
    return {"rows": rows, "fundTotals": fund_totals, "totalAE": total_ae}


def load_previous_fr_data():
    if not PREVIOUS_FR_XLSX.exists():
        return {}
    workbook = load_workbook(PREVIOUS_FR_XLSX, data_only=True)
    result = {}
    for source_name, target_name in (("OPEN LINE FR", "OPEN LINE FR"), ("GSU FR", "GSU FR")):
        if source_name in workbook.sheetnames:
            result[target_name] = parse_previous_fr_sheet(workbook[source_name])
    return result


def previous_fr_sheet(previous_fr, sheet):
    return previous_fr.get(sheet.get("sheetName") or "") or {}


def fr_report_table_with_previous(sheet, previous_fr):
    headers, body = fr_report_table(sheet)
    headers = headers + ["H\nActual Final Expense\nFY 2025-26"]
    previous = previous_fr_sheet(previous_fr, sheet)
    previous_rows = previous.get("rows") or {}
    next_body = []
    records = sheet["records"] + [sheet["total"]]
    for rec, row in zip(records, body):
        raw_plan_head = rec.get("planHead")
        if rec is sheet["total"] or str(raw_plan_head or "").strip().lower() == "total":
            previous_ae = previous.get("totalAE", 0)
        else:
            plan_head = str(raw_plan_head or "").strip()
            lookup_key = plan_head if plan_head else clean_text(rec.get("planName") or "").strip().upper()
            previous_ae = ((previous_rows.get(plan_head) or {}).get("TOTAL") or {}).get("ae", 0)
            if not previous_ae and lookup_key:
                previous_ae = ((previous_rows.get(lookup_key) or {}).get("TOTAL") or {}).get("ae", 0)
        next_body.append(row + [fr_previous_cr(previous_ae)])
    return headers, next_body


def fr_fund_table_with_previous(sheet, previous_fr):
    headers, body = fr_fund_table(sheet)
    headers = headers + ["H\nActual Final Expense\nFY 2025-26"]
    previous = previous_fr_sheet(previous_fr, sheet)
    fund_totals = previous.get("fundTotals") or {}
    next_body = []
    for row in body:
        fund = clean_text(row[0]).strip().upper()
        previous_ae = (fund_totals.get(fund) or {}).get("ae", 0)
        next_body.append(row + [fr_previous_cr(previous_ae)])
    return headers, next_body


def excel_rich_money(value):
    if not isinstance(value, str) or "\n" not in value:
        return value
    main, cr = value.split("\n", 1)
    if not re.search(r"\d", main) or not cr.strip().endswith(" Cr"):
        return value
    return CellRichText(
        TextBlock(InlineFont(rFont="Times New Roman", sz=11), main),
        "\n",
        TextBlock(InlineFont(rFont="Times New Roman", sz=9, color=f"FF{TEAL}"), cr),
    )


def style_ws(ws):
    black = Side(style="thin", color="000000")
    border = Border(left=black, right=black, top=black, bottom=black)
    for row in ws.iter_rows():
        for cell in row:
            cell.value = excel_rich_money(cell.value)
            cell.border = border
            cell.alignment = Alignment(wrap_text=True, vertical="center")
            cell.font = Font(name="Times New Roman", size=10)
            if cell.row == 1:
                cell.font = Font(name="Times New Roman", size=14, bold=True, color=BLUE)
            elif cell.row == 2:
                cell.font = Font(name="Times New Roman", size=10, bold=True, color="607080")
            elif cell.row == 4:
                cell.fill = PatternFill("solid", fgColor=BLUE)
                cell.font = Font(name="Times New Roman", size=10, bold=True, color=WHITE)
            elif cell.row % 2 == 0 and cell.row > 4:
                cell.fill = PatternFill("solid", fgColor=LIGHT)
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        width = max(len(str(c.value or "").split("\n")[0]) for c in col) + 3
        ws.column_dimensions[letter].width = min(max(width, 10), 28)
    ws.page_margins.left = ws.page_margins.right = ws.page_margins.top = ws.page_margins.bottom = 0.25
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1


def write_excel(sections, output_path=XLSX):
    wb = Workbook()
    wb.remove(wb.active)
    for title, headers, body in sections:
        ws = wb.create_sheet(re.sub(r"[\\/?*\[\]:]", " ", title)[:31])
        ws.append([title])
        ws.append(["Figures in '000 with Crore shown below. Generated from latest portal data."])
        ws.append([])
        ws.append(headers)
        for row in body:
            ws.append(row)
        style_ws(ws)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)


def pdf_escape(value):
    return clean_text(value).replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def pdf_text_at(x, y, text, size=10, bold=False):
    font = "F2" if bold else "F1"
    return f"BT /{font} {size} Tf {x:.2f} {y:.2f} Td ({pdf_escape(text)}) Tj ET\n"


def pdf_rect(x, y, w, h, fill=None, stroke=True):
    commands = []
    if fill:
        r = int(fill[0:2], 16) / 255
        g = int(fill[2:4], 16) / 255
        b = int(fill[4:6], 16) / 255
        commands.append(f"{r:.3f} {g:.3f} {b:.3f} rg\n")
    commands.append(f"{x:.2f} {y:.2f} {w:.2f} {h:.2f} re ")
    if fill and stroke:
        commands.append("B\n")
    elif fill:
        commands.append("f\n")
    else:
        commands.append("S\n")
    return "".join(commands)


def pdf_color(color):
    r = int(color[0:2], 16) / 255
    g = int(color[2:4], 16) / 255
    b = int(color[4:6], 16) / 255
    return f"{r:.3f} {g:.3f} {b:.3f} rg\n"


def shorten_for_pdf(value, limit):
    text = clean_text(value).replace("\n", " / ")
    return text if len(text) <= limit else text[: max(0, limit - 1)] + "."


def pdf_column_widths(headers, page_width):
    weights = column_weights(headers)
    return [page_width * weight for weight in weights]


def pdf_table_pages(title, headers, rows):
    page_w, page_h, margin = 842, 595, 18
    table_w = page_w - margin * 2
    col_widths = pdf_column_widths(headers, table_w)
    compact = len(headers) > 10
    row_h = 24 if compact else 28
    header_h = 30 if compact else 36
    header_font = 7 if compact else 9
    body_font = 7.2 if compact else 10
    max_rows = int((page_h - 95 - header_h) // row_h)
    pages = []
    for start in range(0, max(len(rows), 1), max_rows):
        part = rows[start:start + max_rows]
        y = page_h - margin - 18
        content = "0 0 0 RG 0.4 w\n"
        content += pdf_color(BLUE)
        content += pdf_text_at(margin, y, title if start == 0 else f"{title} continued", 15, True)
        y -= 18
        content += pdf_color("666666")
        content += pdf_text_at(margin, y, "Figures in '000 with Crore equivalent below where applicable. Generated from latest portal data.", 8)
        y -= 22
        x = margin
        for idx, header in enumerate(headers):
            w = col_widths[idx]
            content += pdf_rect(x, y - header_h + 4, w, header_h, BLUE)
            content += pdf_color(WHITE)
            content += pdf_text_at(x + 2, y - 11, shorten_for_pdf(header, max(6, int(w / 4.2))), header_font, True)
            x += w
        y -= header_h
        for ridx, row in enumerate(part):
            first = clean_text(row[0]).strip().lower() if row else ""
            fill = "D9EAF7" if ridx % 2 else WHITE
            if first == "total":
                fill = "C8D6E8"
            x = margin
            for cidx, value in enumerate(row):
                w = col_widths[cidx]
                cell_fill = fill
                text_color = BLACK
                if is_percent_header(headers[cidx]) and clean_text(value).strip():
                    cell_fill = utilization_fill(numeric_prefix(value), light=(first != "total"))
                    text_color = BLACK if first != "total" else utilization_text_color(numeric_prefix(value))
                content += pdf_rect(x, y - row_h + 4, w, row_h, cell_fill)
                content += pdf_color(text_color)
                limit = max(5, int(w / 4.7))
                content += pdf_text_at(x + 2, y - 9, shorten_for_pdf(value, limit), body_font, first == "total")
                x += w
            y -= row_h
        pages.append((page_w, page_h, content))
    return pages


def write_pdf(sections, output_path):
    pages = []
    for title, headers, body in sections:
        pages.extend(pdf_table_pages(title, headers, body))
    write_pdf_pages(pages, output_path)


def write_pdf_pages(pages, output_path):
    objects = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        "",
    ]
    page_refs = []
    next_obj = 3
    for page_w, page_h, content in pages:
        content_bytes = content.encode("latin-1", errors="replace")
        page_obj = next_obj
        content_obj = next_obj + 1
        page_refs.append(f"{page_obj} 0 R")
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_w} {page_h}] /Resources << /Font << /F1 {len(pages) * 2 + 3} 0 R /F2 {len(pages) * 2 + 4} 0 R >> >> /Contents {content_obj} 0 R >>")
        objects.append(f"<< /Length {len(content_bytes)} >>\nstream\n{content}\nendstream")
        next_obj += 2
    objects[1] = f"<< /Type /Pages /Count {len(page_refs)} /Kids [{' '.join(page_refs)}] >>"
    objects.append("<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >>")
    objects.append("<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    offsets = []
    data = b"%PDF-1.4\n"
    for idx, obj in enumerate(objects, 1):
        offsets.append(len(data))
        data += f"{idx} 0 obj\n".encode("latin-1")
        data += obj.encode("latin-1", errors="replace")
        data += b"\nendobj\n"
    xref = len(data)
    data += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode("latin-1")
    for offset in offsets:
        data += f"{offset:010d} 00000 n \n".encode("latin-1")
    data += f"trailer << /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode("latin-1")
    output_path.write_bytes(data)


def clean_text(value):
    text = str(value if value is not None else "")
    replacements = {"\u2013": "-", "\u2014": "-", "\u2011": "-", "\u00a0": " "}
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return "".join(ch if ch == "\n" or 32 <= ord(ch) <= 126 else " " for ch in text)


def source_clean(value):
    return re.sub(r"\s+", " ", clean_text(value)).strip().upper()


def source_number(value):
    try:
        if value in ("", None):
            return 0.0
        return float(value)
    except Exception:
        return 0.0


def read_source_rows(path):
    if path.suffix.lower() == ".xlsx":
        workbook = load_workbook(path, read_only=True, data_only=True)
        sheet = workbook[workbook.sheetnames[0]]
        return [[cell for cell in row] for row in sheet.iter_rows(values_only=True)]
    workbook = xlrd.open_workbook(str(path))
    sheet = workbook.sheet_by_index(0)
    return [sheet.row_values(index) for index in range(sheet.nrows)]


def source_table(path):
    raw = [row for row in read_source_rows(path) if any(str(cell).strip() for cell in row)]
    header_index = next((idx for idx, row in enumerate(raw) if source_clean(row[0]) == "AU"), -1)
    if header_index < 0:
        raise RuntimeError(f"AU header row not found in {path.name}")
    return {
        "headers": [source_clean(cell) for cell in raw[header_index]],
        "rows": raw[header_index + 1:],
    }


def source_col(headers, needles):
    wanted = [source_clean(item) for item in needles]
    for idx, header in enumerate(headers):
        if all(item in header for item in wanted):
            return idx
    raise RuntimeError("Missing source column: " + " ".join(needles))


def optional_source_col(headers, needles):
    try:
        return source_col(headers, needles)
    except RuntimeError:
        return -1


def source_cell(row, idx):
    return row[idx] if idx >= 0 and idx < len(row) else ""


def source_month_col(headers, label):
    target = source_clean(label)
    for idx, header in enumerate(headers):
        if header == target:
            return idx
    return -1


def code_key(value, prefix):
    match = re.search(rf"{re.escape(prefix)}\s*-\s*([0-9A-Z]+)", clean_text(value), re.I)
    return match.group(1).upper() if match else ""


def matrix_sort_key(label, prefix):
    code = code_key(label, prefix)
    number = re.match(r"(\d+)", code or "")
    suffix = re.sub(r"^\d+", "", code or "")
    return (int(number.group(1)) if number else 999, suffix, clean_text(label))


def smh_code(value):
    return code_key(value, "SMH")


def effective_budget(row, bg_idx, rg_idx):
    bg = source_number(source_cell(row, bg_idx))
    rg = source_number(source_cell(row, rg_idx))
    return rg if rg else bg


def matrix_money_lines(value):
    n = number_value(value)
    if abs(n) < 0.5:
        return ["..", ""]
    return [inr(n), f"{n / 10000:.2f} Cr"]


def add_matrix_amount(store, group, smh, metric, amount):
    if not group or smh not in SMH_COLUMNS:
        return
    bucket = store.setdefault(group, {item: {"ACT": 0.0, "BUD PROP": 0.0, "VAR": 0.0} for item in SMH_COLUMNS})
    bucket[smh][metric] += source_number(amount)


def build_smh_matrix_data():
    period = period_from_meta()
    year_dir = ROOT / "data" / "source-files" / "2026-2027"
    budget = source_table(year_dir / "pu-dept-demand-smh-budget.xls")
    actual = source_table(year_dir / "pu-dept-demand-smh-actual.xls")
    budget_headers = budget["headers"]
    actual_headers = actual["headers"]
    b_dept = source_col(budget_headers, ["DEPARTMENTCODE"])
    b_smh = source_col(budget_headers, ["SMH"])
    b_pu = source_col(budget_headers, ["PUCODE"])
    b_bg = source_col(budget_headers, ["BG_ISL", "2026-2027"])
    b_rg = optional_source_col(budget_headers, ["RG", "2026-2027"])
    a_dept = source_col(actual_headers, ["DEPARTMENTCODE"])
    a_smh = source_col(actual_headers, ["SMH"])
    a_pu = source_col(actual_headers, ["PUCODE"])
    month_labels = [f"{month} {2026 if idx < 9 else 2027}" for idx, month in enumerate(["APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR"])]
    actual_month_cols = [source_month_col(actual_headers, label) for label in month_labels[:period["count"]]]

    pu = {}
    dept = {}
    for row in budget["rows"]:
        smh = smh_code(source_cell(row, b_smh))
        oba = effective_budget(row, b_bg, b_rg)
        bp = oba / 12 * period["count"]
        add_matrix_amount(pu, clean_text(source_cell(row, b_pu)).strip(), smh, "BUD PROP", bp)
        add_matrix_amount(dept, clean_text(source_cell(row, b_dept)).strip(), smh, "BUD PROP", bp)
    for row in actual["rows"]:
        smh = smh_code(source_cell(row, a_smh))
        actual_value = sum(source_number(source_cell(row, idx)) for idx in actual_month_cols if idx >= 0)
        add_matrix_amount(pu, clean_text(source_cell(row, a_pu)).strip(), smh, "ACT", actual_value)
        add_matrix_amount(dept, clean_text(source_cell(row, a_dept)).strip(), smh, "ACT", actual_value)
    for store in (pu, dept):
        for bucket in store.values():
            for smh in SMH_COLUMNS:
                bucket[smh]["VAR"] = bucket[smh]["ACT"] - bucket[smh]["BUD PROP"]
    meta = load_current_meta()
    subtitle = (
        f"Figures in '000 of rupees | Completed actual basis up to {period['label']} "
        f"({period['count']:02d} months) | Data as on {meta.get('statusAsOn', '')} | "
        "Budget proportion uses RG where available, otherwise BG_ISL"
    )
    return [
        {
            "title": "NORTHERN RAILWAY - MORADABAD DIVISION - PRIMARY UNIT - ALL PRIMARY UNITS",
            "subtitle": f"SMH WISE PRIMARY UNIT REPORT - FY 2026-2027 | {subtitle}",
            "left": "PRIMARY UNITS",
            "prefix": "PU",
            "groups": sorted(pu.items(), key=lambda item: matrix_sort_key(item[0], "PU")),
        },
        {
            "title": "NORTHERN RAILWAY - MORADABAD DIVISION - PRIMARY UNIT - ALL PRIMARY UNITS",
            "subtitle": f"SMH WISE DEPARTMENT WISE REPORT - FY 2026-2027 | {subtitle}",
            "left": "DEPARTMENTS",
            "prefix": "",
            "groups": sorted(dept.items(), key=lambda item: clean_text(item[0])),
        },
    ]


def pdf_text_lines(x, y, lines, size=8, bold=False, leading=None):
    leading = leading or size + 2
    return "".join(pdf_text_at(x, y - idx * leading, line, size, bold) for idx, line in enumerate(lines) if line)


def pdf_center_text(x, y, w, text, size=8, bold=False):
    return pdf_text_at(x + max(2, (w - len(clean_text(text)) * size * 0.42) / 2), y, text, size, bold)


def matrix_cell_text(x, y, w, h, value, bold=False):
    lines = matrix_money_lines(value)
    if lines[0] == "..":
        return pdf_center_text(x, y - h / 2 + 4, w, "..", 8, bold)
    return (
        pdf_text_at(x + 2, y - 8, shorten_for_pdf(lines[0], max(5, int(w / 4))), 7.2, bold)
        + pdf_text_at(x + 2, y - 17, lines[1], 6.2, False)
    )


def write_smh_matrix_pdf(output_path=SMH_MATRIX_PDF):
    sections = build_smh_matrix_data()
    page_w, page_h, margin = 1191, 842, 22
    table_w = page_w - margin * 2
    label_w, metric_w = 145, 58
    smh_w = (table_w - label_w - metric_w) / (len(SMH_COLUMNS) + 1)
    row_h, header_h1, header_h2 = 22, 25, 24
    pages = []
    for section in sections:
        groups = section["groups"]
        max_groups = 10
        for start in range(0, len(groups), max_groups):
            part = groups[start:start + max_groups]
            y = page_h - margin
            content = "0 0 0 RG 0.35 w\n"
            content += pdf_color(BLACK)
            title = section["title"] if start == 0 else f"{section['title']} - continued"
            content += pdf_center_text(margin, y - 6, table_w, title, 13, True)
            y -= 18
            content += pdf_center_text(margin, y - 4, table_w, section["subtitle"], 7.5, True)
            y -= 24
            x = margin
            content += pdf_rect(x, y - header_h1 - header_h2, label_w + metric_w, header_h1 + header_h2, "BFBFBF")
            content += pdf_color(WHITE)
            content += pdf_text_at(x + 12, y - 31, section["left"], 9, True)
            x += label_w + metric_w
            content += pdf_rect(x, y - header_h1, smh_w * (len(SMH_COLUMNS) + 1), header_h1, "BFBFBF")
            content += pdf_color(WHITE)
            content += pdf_center_text(x, y - 16, smh_w * (len(SMH_COLUMNS) + 1), "SMHs", 9, True)
            y -= header_h1
            x = margin + label_w + metric_w
            for smh in [*SMH_COLUMNS, "TOTAL"]:
                content += pdf_rect(x, y - header_h2, smh_w, header_h2, "BFBFBF")
                content += pdf_color(WHITE)
                content += pdf_center_text(x, y - 15, smh_w, smh, 8.5, True)
                x += smh_w
            y -= header_h2
            for group_index, (label, bucket) in enumerate(part):
                group_h = row_h * 3
                base_fill = "F7F7F7" if group_index % 2 else WHITE
                content += pdf_rect(margin, y - group_h, label_w, group_h, base_fill)
                content += pdf_color(BLACK)
                content += pdf_text_lines(margin + 6, y - 18, [shorten_for_pdf(label, 25)], 8.2, False)
                for ridx, metric in enumerate(["ACT", "BUD PROP", "VAR"]):
                    row_y = y - ridx * row_h
                    content += pdf_rect(margin + label_w, row_y - row_h, metric_w, row_h, base_fill)
                    content += pdf_color(BLACK)
                    content += pdf_text_at(margin + label_w + 4, row_y - 14, metric, 7.5)
                    x = margin + label_w + metric_w
                    row_total = 0.0
                    for smh in SMH_COLUMNS:
                        val = bucket[smh][metric]
                        row_total += val
                        fill = base_fill
                        if metric == "VAR" and abs(val) >= 0.5:
                            fill = RED_LIGHT if val > 0 else GREEN_LIGHT
                        content += pdf_rect(x, row_y - row_h, smh_w, row_h, fill)
                        content += pdf_color(BLACK)
                        content += matrix_cell_text(x, row_y, smh_w, row_h, val, False)
                        x += smh_w
                    fill = "D9EAF7"
                    if metric == "VAR" and abs(row_total) >= 0.5:
                        fill = RED_LIGHT if row_total > 0 else GREEN_LIGHT
                    content += pdf_rect(x, row_y - row_h, smh_w, row_h, fill)
                    content += pdf_color(BLACK)
                    content += matrix_cell_text(x, row_y, smh_w, row_h, row_total, True)
                y -= group_h
            content += pdf_color("666666")
            page_no = len(pages) + 1
            content += pdf_text_at(margin, 13, f"Page {page_no} | Generated from latest portal data", 7)
            pages.append((page_w, page_h, content))
    write_pdf_pages(pages, output_path)


def money_like_text(text):
    parts = clean_text(text).split("\n")
    return len(parts) == 2 and bool(re.search(r"\d", parts[0])) and parts[1].strip().endswith(" Cr")


def text_runs(text, size=900, bold=False, color=BLACK):
    bold_attr = ' b="1"' if bold else ""
    runs = []
    for idx, part in enumerate(clean_text(text).split("\n")):
        if idx:
            runs.append("<a:br/>")
        run_size = max(680, size - 180) if money_like_text(text) and idx == 1 else size
        run_color = TEAL if money_like_text(text) and idx == 1 and color == BLACK else color
        runs.append(f'<a:r><a:rPr lang="en-US" sz="{run_size}"{bold_attr}><a:solidFill><a:srgbClr val="{run_color}"/></a:solidFill><a:latin typeface="Times New Roman"/></a:rPr><a:t>{xesc(part)}</a:t></a:r>')
    return "".join(runs)


def ppt_text_box(shape_id, x, y, w, h, text, size=1200, bold=False, fill=None, color=BLACK, align="ctr"):
    fill_xml = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else "<a:noFill/>"
    return f'''<p:sp><p:nvSpPr><p:cNvPr id="{shape_id}" name="Text {shape_id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>{fill_xml}<a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="ctr" lIns="50000" rIns="50000" tIns="25000" bIns="25000"/><a:lstStyle/><a:p><a:pPr algn="{align}"/>{text_runs(text, size, bold, color)}</a:p></p:txBody></p:sp>'''


def tc_pr(fill):
    border = f'<a:solidFill><a:srgbClr val="{BLACK}"/></a:solidFill>'
    lines = "".join(f'<a:ln{side} w="12700">{border}</a:ln{side}>' for side in ["L", "R", "T", "B"])
    # CT_TableCellProperties requires border lines before the fill element.
    # Well-formed XML in the opposite order triggers PowerPoint content repair.
    return f'<a:tcPr marL="12000" marR="12000" marT="8000" marB="8000">{lines}<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill></a:tcPr>'


def table_cell(text, fill, size, bold=False, color=BLACK, align="ctr"):
    anchor = "ctr"
    return f'''<a:tc><a:txBody><a:bodyPr wrap="square" anchor="{anchor}" lIns="18000" rIns="18000" tIns="10000" bIns="10000"/><a:lstStyle/><a:p><a:pPr algn="{align}"/>{text_runs(text, size, bold, color)}</a:p></a:txBody>{tc_pr(fill)}</a:tc>'''


def column_weights(headers):
    weights = []
    has_department = len(headers) > 1 and "department" in clean_text(headers[1]).lower()
    for index, header in enumerate(headers):
        label = clean_text(header).lower()
        if index == 0:
            weights.append(1.35 if has_department else 1.65)
        elif "department" in label or "name" in label:
            weights.append(2.05)
        elif "%" in label or "percent" in label:
            weights.append(0.72)
        elif "variation" in label or "remaining" in label:
            weights.append(1.18)
        elif "oba" in label or "bp" in label or "actual" in label or "ae" in label or "sba" in label:
            weights.append(1.08)
        else:
            weights.append(1.05)
    total = sum(weights) or 1
    return [weight / total for weight in weights]


def numeric_prefix(value):
    match = re.search(r"-?\d+(?:\.\d+)?", clean_text(value).replace(",", ""))
    return float(match.group(0)) if match else 0


def is_percent_header(header):
    label = clean_text(header).lower()
    return "%" in label or "expensed" in label or "utilized" in label


def ppt_table(shape_id, x, y, w, h, headers, rows):
    col_count = len(headers)
    row_count = len(rows) + 1
    row_h = int(h / max(row_count, 1))
    header_size = 1080 if col_count <= 8 else 1000
    body_size = 1000
    col_widths = [int(w * weight) for weight in column_weights(headers)]
    col_widths[-1] += int(w) - sum(col_widths)
    grid = "".join(f'<a:gridCol w="{col_w}"/>' for col_w in col_widths)
    trs = [
        f'<a:tr h="{row_h}">' + "".join(table_cell(head, BLUE, header_size, True, WHITE, "ctr") for head in headers) + "</a:tr>"
    ]
    percent_cols = {idx for idx, head in enumerate(headers) if is_percent_header(head)}
    for r_idx, row in enumerate(rows):
        first = clean_text(row[0]).strip().lower() if row else ""
        base_fill = "C8D6E8" if first == "total" else ("D9EAF7" if r_idx % 2 else WHITE)
        cells = []
        for c_idx, value in enumerate(row):
            align = "l" if c_idx == 1 and ("department" in clean_text(headers[c_idx]).lower() or "name" in clean_text(headers[c_idx]).lower()) else "ctr"
            bold = first == "total" or c_idx in (0, col_count - 1) or c_idx in percent_cols
            size = body_size + 130 if first == "total" and col_count <= 9 else body_size
            fill = base_fill
            color = BLACK
            if c_idx in percent_cols and clean_text(value).strip():
                n = numeric_prefix(value)
                fill = utilization_fill(n, light=(first != "total"))
                color = BLACK if first != "total" else utilization_text_color(n)
            cells.append(table_cell(value, fill, size, bold, color, align))
        trs.append(f'<a:tr h="{row_h}">' + "".join(cells) + "</a:tr>")
    return f'''<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="{shape_id}" name="Table {shape_id}"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1" bandRow="1"><a:tableStyleId>{{5940675A-B579-460E-94D1-54222C63F5DA}}</a:tableStyleId></a:tblPr><a:tblGrid>{grid}</a:tblGrid>{''.join(trs)}</a:tbl></a:graphicData></a:graphic></p:graphicFrame>'''


def editable_slide_xml(title, subtitle="", headers=None, rows=None):
    shapes = [
        ppt_text_box(2, 130000, 45000, SLIDE_W - 260000, 365000, title, 1900, True, None, "22A7D8"),
    ]
    if subtitle:
        shapes.append(ppt_text_box(3, 130000, 430000, SLIDE_W - 260000, 215000, subtitle, 900, False, None, BLACK, "r"))
    if headers and rows is not None:
        shapes.append(ppt_table(4, 130000, 670000, SLIDE_W - 260000, SLIDE_H - 800000, headers, rows))
    sp_tree = "".join(shapes)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>{sp_tree}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'''


def cover_slide_xml(title, subtitle):
    shapes = [
        ppt_text_box(2, 0, 0, SLIDE_W, 540000, "NORTHERN RAILWAY - MORADABAD DIVISION", 1350, True, NAVY, WHITE),
        ppt_text_box(3, 420000, 1180000, SLIDE_W - 840000, 760000, title, 2400, True, None, "22A7D8"),
        ppt_text_box(4, 860000, 2040000, SLIDE_W - 1720000, 430000, subtitle, 980, False, LIGHT, BLACK),
        ppt_text_box(5, 1350000, 3120000, 2400000, 720000, "Green\nWithin control", 920, True, GREEN_LIGHT, BLACK),
        ppt_text_box(6, 4860000, 3120000, 2400000, 720000, "Amber\nWatch range", 920, True, AMBER_LIGHT, BLACK),
        ppt_text_box(7, 8370000, 3120000, 2400000, 720000, "Red\nImmediate review", 920, True, RED_LIGHT, BLACK),
        ppt_text_box(8, 0, SLIDE_H - 420000, SLIDE_W, 420000, "Figures in thousands with Crore equivalent shown inside table cells", 900, False, BLUE, WHITE),
    ]
    sp_tree = "".join(shapes)
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>{sp_tree}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'''


def split_section(title, headers, rows):
    slides = []
    col_count = len(headers)
    if col_count <= 6:
        max_rows = 18
    elif col_count <= 10:
        max_rows = 13
    else:
        max_rows = 10
    for r_idx in range(0, len(rows), max_rows):
        part_rows = rows[r_idx:r_idx + max_rows]
        slide_title = title if len(rows) <= max_rows else f"{title} (Rows {r_idx + 1}-{r_idx + len(part_rows)})"
        slides.append(editable_slide_xml(slide_title, "Figures in thousands.", headers, part_rows))
    return slides


def build_pptx_from_template(output_path, sections, subtitle):
    if not TEMPLATE_PPTX.exists():
        raise RuntimeError(f"Template PPTX not found: {TEMPLATE_PPTX}")
    slides = [cover_slide_xml("Moradabad Division Budget & FR Analysis", subtitle)]
    for title, headers, rows in sections:
        slides.extend(split_section(title, headers, rows))
    with zipfile.ZipFile(TEMPLATE_PPTX, "r") as src:
        content = src.read("[Content_Types].xml").decode("utf-8")
        pres = src.read("ppt/presentation.xml").decode("utf-8")
        pres_rels = src.read("ppt/_rels/presentation.xml.rels").decode("utf-8")
        slide_rel = src.read("ppt/slides/_rels/slide1.xml.rels")
        content = re.sub(r'<Override PartName="/ppt/slides/slide\d+\.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide\+xml"/>', "", content)
        slide_overrides = "".join(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' for i in range(1, len(slides) + 1))
        content = content.replace("</Types>", f"{slide_overrides}</Types>")
        sld_ids = "".join(f'<p:sldId id="{255 + i}" r:id="rIdSlide{i}"/>' for i in range(1, len(slides) + 1))
        pres = re.sub(r"<p:sldIdLst>.*?</p:sldIdLst>", f"<p:sldIdLst>{sld_ids}</p:sldIdLst>", pres, flags=re.S)
        pres_rels = re.sub(r'<Relationship Id="rId\d+" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide\d+\.xml"/>', "", pres_rels)
        slide_rels = "".join(f'<Relationship Id="rIdSlide{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide{i}.xml"/>' for i in range(1, len(slides) + 1))
        pres_rels = pres_rels.replace("</Relationships>", f"{slide_rels}</Relationships>")
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as dst:
            for item in src.infolist():
                name = item.filename
                if name == "[Content_Types].xml" or name in {"ppt/presentation.xml", "ppt/_rels/presentation.xml.rels"}:
                    continue
                if re.match(r"ppt/slides/(?:_rels/)?slide\d+\.xml(?:\.rels)?$", name):
                    continue
                dst.writestr(item, src.read(name))
            dst.writestr("[Content_Types].xml", content)
            dst.writestr("ppt/presentation.xml", pres)
            dst.writestr("ppt/_rels/presentation.xml.rels", pres_rels)
            for i, xml in enumerate(slides, 1):
                dst.writestr(f"ppt/slides/slide{i}.xml", xml)
                dst.writestr(f"ppt/slides/_rels/slide{i}.xml.rels", slide_rel)
    from test_pptx_integrity import validate
    validate(output_path)


class YearlyComparisonTemplatePatch:
    YEARS = ["2024-25", "2025-26", "2026-27"]
    MONTHS = ["APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR"]
    PU_SLIDE_CODES = ["10", "11", "12", "15", "20", "25", "26", "27", "28", "32"]

    def __init__(self, payload, reports, period):
        self.payload = payload
        self.reports = reports
        self.period = period
        self.demand_rows = self._rows_by_code(payload.get("demand", {}).get("rows", []), r"Demand\s+([0-9A-Z]+)")
        pu_rows = [*payload.get("staff", {}).get("rows", []), *payload.get("nonstaff", {}).get("rows", [])]
        self.pu_rows = self._rows_by_code(pu_rows, r"PU\s*-\s*([0-9A-Z]+)")
        self.demand_budget = self._budget_by_code("demand", r"Demand\s+([0-9A-Z]+)")
        self.pu_budget = self._budget_by_code("pu", r"PU\s*-\s*([0-9A-Z]+)")
        self.monthly_pu = self._monthly_by_code("pu", r"PU\s*-\s*([0-9A-Z]+)")

    def _rows_by_code(self, rows, pattern):
        out = {}
        for row in rows:
            if row.get("Name") == "Total":
                continue
            match = re.search(pattern, row.get("Name", ""), re.I)
            if match:
                out[match.group(1).upper()] = row
        return out

    def _budget_by_code(self, group, pattern):
        out = {}
        for label, values in (self.reports.get("budget", {}).get(group, {}) or {}).items():
            match = re.search(pattern, label, re.I)
            if match:
                out.setdefault(match.group(1).upper(), {}).update(values)
        return out

    def _monthly_by_code(self, group, pattern):
        out = {}
        for label, values in (self.reports.get("monthly", {}).get(group, {}) or {}).items():
            match = re.search(pattern, label, re.I)
            if match:
                out.setdefault(match.group(1).upper(), {}).update(values)
        return out

    def _cr(self, value, digits=2):
        return f"{float(value or 0) / 10000:.{digits}f}"

    def _pct(self, numerator, denominator, digits=1, suffix=True):
        value = (float(numerator or 0) / float(denominator or 0) * 100) if float(denominator or 0) else 0
        return f"{value:.{digits}f}%" if suffix else f"{value:.{digits}f}"

    def _annual_source(self, code, kind):
        source = deepcopy((self.demand_budget if kind == "demand" else self.pu_budget).get(code, {}))
        current = (self.demand_rows if kind == "demand" else self.pu_rows).get(code)
        if current:
            source["2026-27"] = {"oba": current.get("OBA", 0), "bp": current.get("BP", 0), "ae": current.get("AE", 0)}
        return source

    def _annual_rows(self, code, kind):
        source = self._annual_source(code, kind)
        rows = []
        for year in self.YEARS:
            values = source.get(year) or {}
            oba = float(values.get("oba") or 0)
            bp = float(values.get("bp") or 0)
            ae = float(values.get("ae") or 0)
            digits = 2 if kind == "demand" else 1
            rows.append([
                year,
                self._cr(oba, digits),
                self._cr(bp, digits),
                self._cr(ae, digits),
                self._cr(oba - ae, digits),
                self._pct(ae, oba, 1 if kind == "demand" else 0),
                self._pct(ae, bp, 1 if kind == "demand" else 0),
            ])
        return rows

    def _monthly_values(self, code, year="2026-27"):
        values = (self.monthly_pu.get(code, {}) or {}).get(year) or []
        values = [float(value or 0) for value in values]
        visible = []
        for idx in range(len(self.MONTHS)):
            if year != "2026-27" or idx < self.period["count"]:
                visible.append(self._cr(values[idx] if idx < len(values) else 0, 2))
            else:
                visible.append("-")
        return visible

    def _tokens(self, xml):
        return [unescape(match.group(1)) for match in re.finditer(r"<a:t>(.*?)</a:t>", xml, flags=re.S)]

    def _replace_tokens(self, xml, tokens):
        iterator = iter(tokens)

        def repl(_match):
            return f"<a:t>{xesc(next(iterator))}</a:t>"

        return re.sub(r"<a:t>.*?</a:t>", repl, xml, flags=re.S)

    def _patch_current_row(self, tokens, values):
        indices = [idx for idx, token in enumerate(tokens) if token == values[0]]
        if indices:
            start = indices[0] + 1
            tokens[start:start + 6] = values[1:7]
        return tokens

    def _patch_current_months(self, tokens, values, year="2026-27"):
        indices = [idx for idx, token in enumerate(tokens) if token == year]
        if len(indices) > 1:
            start = indices[1] + 1
            tokens[start:start + 12] = values
        return tokens

    def patch_slide(self, slide_no, xml):
        tokens = self._tokens(xml)
        if not tokens:
            return xml
        if slide_no == 1 and len(tokens) >= 3:
            tokens[2] = f"FY 2024-25 | FY 2025-26 | FY 2026-27 through {self.period['label']}"
        elif slide_no == 2 and len(tokens) >= 6:
            tokens[5] = f"3. PU charts compare monthly AE for three financial years; FY 2026-27 uses actuals through {self.period['label'].title()}."
        elif 3 <= slide_no <= 13:
            code = f"{slide_no:02d}"
            rows = self._annual_rows(code, "demand")
            for row in rows:
                tokens = self._patch_current_row(tokens, row)
        elif 15 <= slide_no <= 24:
            code = self.PU_SLIDE_CODES[slide_no - 15]
            rows = self._annual_rows(code, "pu")
            for row in rows:
                tokens = self._patch_current_row(tokens, row)
            for year in self.YEARS:
                tokens = self._patch_current_months(tokens, self._monthly_values(code, year), year)
        return self._replace_tokens(xml, tokens)

    def _replace_num_cache(self, block, values):
        match = re.search(r"<c:numCache>(.*?)</c:numCache>", block, flags=re.S)
        if not match:
            return block
        body = match.group(1)
        fmt = re.search(r"<c:formatCode>.*?</c:formatCode>", body, flags=re.S)
        fmt_text = fmt.group(0) if fmt else "<c:formatCode>General</c:formatCode>"
        pts = "".join(f'<c:pt idx="{idx}"><c:v>{value}</c:v></c:pt>' for idx, value in enumerate(values))
        cache = f"<c:numCache>{fmt_text}<c:ptCount val=\"{len(values)}\"/>{pts}</c:numCache>"
        return block[:match.start()] + cache + block[match.end():]

    def _patch_series(self, xml, values_by_series):
        idx = -1

        def repl(match):
            nonlocal idx
            idx += 1
            values = values_by_series.get(idx)
            return self._replace_num_cache(match.group(0), values) if values is not None else match.group(0)

        return re.sub(r"<c:ser>.*?</c:ser>", repl, xml, flags=re.S)

    def patch_chart(self, chart_name, xml):
        match = re.search(r"chart(\d+)\.xml$", chart_name)
        if not match:
            return xml
        chart_no = int(match.group(1))
        if 1 <= chart_no <= 22:
            slide_no = 3 + ((chart_no - 1) // 2)
            code = f"{slide_no:02d}"
            rows = self._annual_rows(code, "demand")
            if chart_no % 2:
                values = {0: [row[1] for row in rows], 1: [row[2] for row in rows], 2: [row[3] for row in rows]}
            else:
                values = {0: [row[5].rstrip("%") for row in rows], 1: [row[6].rstrip("%") for row in rows]}
            return self._patch_series(xml, values)
        if 23 <= chart_no <= 32:
            code = self.PU_SLIDE_CODES[chart_no - 23]
            values = {idx: [value for value in self._monthly_values(code, year) if value != "-"]
                      for idx, year in enumerate(self.YEARS)}
            return self._patch_series(xml, values)
        return xml


def chart_workbook(chart_xml):
    """Embed chart values so PowerPoint Edit Data uses the refreshed numbers."""
    from io import BytesIO
    from xml.etree import ElementTree as ET
    from openpyxl.utils.cell import range_boundaries
    ns = {"c": "http://schemas.openxmlformats.org/drawingml/2006/chart"}
    workbook = Workbook()
    workbook.remove(workbook.active)
    chart = ET.fromstring(chart_xml)
    for ref in chart.findall(".//c:numRef", ns) + chart.findall(".//c:strRef", ns):
        formula = ref.findtext("c:f", namespaces=ns)
        if not formula or "!" not in formula:
            continue
        sheet_name, address = formula.rsplit("!", 1)
        sheet_name = sheet_name.strip("'")
        sheet = workbook[sheet_name] if sheet_name in workbook.sheetnames else workbook.create_sheet(sheet_name)
        col1, row1, col2, row2 = range_boundaries(address.replace("$", ""))
        numeric = ref.tag.endswith("numRef")
        cache = ref.find("c:numCache" if numeric else "c:strCache", ns)
        if cache is None:
            continue
        for point in cache.findall("c:pt", ns):
            index = int(point.attrib["idx"])
            value = point.findtext("c:v", namespaces=ns)
            row = row1 + index if row2 > row1 else row1
            col = col1 if row2 > row1 else col1 + index
            sheet.cell(row, col, float(value) if numeric and value else value)
    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def refresh_yearly_comparison_pptx():
    if not YEARLY_COMPARISON_TEMPLATE.exists():
        raise RuntimeError(f"Yearly comparison PPTX template not found: {YEARLY_COMPARISON_TEMPLATE}")
    payload = apply_completed_period(load_json_assignment(ROOT / "data" / "current_payload.js", "window.CURRENT_PAYLOAD"))
    reports = json.loads((ROOT / "data" / "reports-data.json").read_text(encoding="utf-8-sig"))
    period = period_from_meta()
    patcher = YearlyComparisonTemplatePatch(payload, reports, period)
    tmp = DRM_YEARLY_COMPARISON_PPTX.with_suffix(".tmp.pptx")
    with zipfile.ZipFile(YEARLY_COMPARISON_TEMPLATE, "r") as src, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as dst:
        embedded = {}
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename == "[Content_Types].xml":
                text = data.decode("utf-8")
                if 'Extension="xlsx"' not in text:
                    text = text.replace("</Types>", '<Default Extension="xlsx" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/></Types>')
                data = text.encode("utf-8")
            if item.filename.startswith("ppt/slides/slide") and item.filename.endswith(".xml") and "_rels" not in item.filename:
                slide_no = int(re.search(r"slide(\d+)\.xml", item.filename).group(1))
                data = patcher.patch_slide(slide_no, data.decode("utf-8", errors="ignore")).encode("utf-8")
            elif item.filename.startswith("ppt/charts/chart") and item.filename.endswith(".xml"):
                data = patcher.patch_chart(item.filename, data.decode("utf-8", errors="ignore")).encode("utf-8")
                number = int(re.search(r"chart(\d+)\.xml", item.filename).group(1))
                embedded[f"ppt/embeddings/chart{number}.xlsx"] = chart_workbook(data)
            elif re.fullmatch(r"ppt/charts/_rels/chart\d+\.xml.rels", item.filename):
                number = int(re.search(r"chart(\d+)\.xml", item.filename).group(1))
                text = data.decode("utf-8")
                text = re.sub(r'<Relationship\b[^>]*TargetMode="External"[^>]*/>',
                              f'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/package" Target="../embeddings/chart{number}.xlsx"/>', text)
                data = text.encode("utf-8")
            dst.writestr(item, data)
        for name, data in embedded.items():
            dst.writestr(name, data)
    shutil.move(tmp, DRM_YEARLY_COMPARISON_PPTX)
    with zipfile.ZipFile(DRM_YEARLY_COMPARISON_PPTX) as z:
        assert z.testzip() is None
        assert "ppt/presentation.xml" in z.namelist()
    from test_pptx_integrity import validate
    validate(DRM_YEARLY_COMPARISON_PPTX)


def drm_sections(payload, reports, fr, previous_fr, current_basis, fr_as_on, h_mode="full_previous"):
    period = period_from_meta()
    staff_rows = filtered_pu_rows(payload["staff"]["rows"], ["01", "02", "03", "04", "07", "10", "11", "12", "13", "15", "16", "25"])
    nonstaff_rows = filtered_pu_rows(payload["nonstaff"]["rows"], ["27", "28", "30", "32", "60"])
    if h_mode == "till_actual":
        demand_actuals = previous_actual_map(payload["demand_prev"]["rows"])
        pu_actuals = previous_actual_map(payload["pu_prev"]["rows"])
        h_period = period["label"].replace("2026", "2025")
        h_label = f"H\nActual Expenditure\nup to {h_period}"
        subtitle_suffix = f"H column: actual expenditure up to {h_period}"
    else:
        demand_actuals = previous_final_actual_map(reports, "demand", payload["demand"]["rows"])
        pu_actuals = previous_final_actual_map(reports, "pu", payload["pu_prev"]["rows"])
        h_label = "H\nActual Final Expenditure\nFY 2025-26"
        subtitle_suffix = "H column: actual final expenditure FY 2025-26"
    demand_cols, demand_rows = add_previous_actual_column(payload["demand"], payload["demand"]["rows"], demand_actuals, label=h_label)
    staff_cols, staff_rows = add_previous_actual_column(payload["staff"], staff_rows, pu_actuals, label=h_label)
    nonstaff_cols, nonstaff_rows = add_previous_actual_column(payload["nonstaff"], nonstaff_rows, pu_actuals, label=h_label)
    sections = [
        (f"Demand SMH Wise - {current_basis}", *table_from_payload(payload["demand"], demand_cols, demand_rows)),
        (f"PU Wise - Staff - {current_basis}", *table_from_payload(payload["staff"], staff_cols, staff_rows)),
        (f"PU Wise - Non-Staff Part 1 - {current_basis}", *table_from_payload(payload["nonstaff"], nonstaff_cols, nonstaff_rows)),
        (f"Open Line FR Report - As On {fr_as_on}", *fr_report_table_with_previous(fr[0], previous_fr)),
        (f"Open Line FR Fund Wise - As On {fr_as_on}", *fr_fund_table_with_previous(fr[0], previous_fr)),
    ]
    subtitle = f"Accounts Dept | FY 2026-2027 | DRM Budget & FR Analysis | Completed {period['label']} | {subtitle_suffix}"
    return sections, subtitle


def build():
    payload = apply_completed_period(load_json_assignment(ROOT / "data" / "current_payload.js", "window.CURRENT_PAYLOAD"))
    reports = json.loads((ROOT / "data" / "reports-data.json").read_text(encoding="utf-8-sig"))
    fr = load_fr_data()
    previous_fr = load_previous_fr_data()
    fr_as_on = load_fr_as_on()
    current_basis = current_as_on_label()
    demand_cols = payload["demand"]["columns"]
    staff_cols = payload["staff"]["columns"]
    nonstaff_cols = payload["nonstaff"]["columns"]
    current_sections = [
        (f"Demand SMH Wise - {current_basis}", *table_from_payload(payload["demand"], demand_cols, payload["demand"]["rows"])),
        (f"PU Staff Current Year - {current_basis}", *table_from_payload(payload["staff"], staff_cols, payload["staff"]["rows"])),
        (f"PU Non Staff Current Year - {current_basis}", *table_from_payload(payload["nonstaff"], nonstaff_cols, payload["nonstaff"]["rows"])),
        (f"PU Previous Year Comparison - {current_basis}", *table_from_payload(payload["pu_prev"])),
        (f"Demand Previous Year Comparison - {current_basis}", *table_from_payload(payload["demand_prev"])),
    ]
    drm_sections_full, drm_subtitle_full = drm_sections(payload, reports, fr, previous_fr, current_basis, fr_as_on, "full_previous")
    drm_sections_till, drm_subtitle_till = drm_sections(payload, reports, fr, previous_fr, current_basis, fr_as_on, "till_actual")
    fr_sections = [
        (f"Open Line FR Report - As On {fr_as_on}", *fr_report_table(fr[0])),
        (f"Open Line FR Fund Wise - As On {fr_as_on}", *fr_fund_table(fr[0])),
        (f"GSU FR Report - As On {fr_as_on}", *fr_report_table(fr[1])),
        (f"GSU FR Fund Wise - As On {fr_as_on}", *fr_fund_table(fr[1])),
    ]
    OUT.mkdir(parents=True, exist_ok=True)
    write_excel(current_sections, CURRENT_XLSX)
    write_excel(fr_sections, FR_XLSX)
    write_excel(drm_sections_full, XLSX)
    write_pdf(current_sections, CURRENT_PDF)
    write_pdf(fr_sections, FR_PDF)
    write_smh_matrix_pdf(SMH_MATRIX_PDF)
    period = period_from_meta()
    build_pptx_from_template(CURRENT_PPTX, current_sections, f"Accounts Dept | FY 2026-2027 | Current / Previous Year Budget Analysis | Completed {period['label']}")
    build_pptx_from_template(PPTX, drm_sections_full, drm_subtitle_full)
    build_pptx_from_template(DRM_TILL_ACTUAL_PPTX, drm_sections_till, drm_subtitle_till)
    build_pptx_from_template(DRM_FULL_PREVIOUS_PPTX, drm_sections_full, drm_subtitle_full)
    refresh_yearly_comparison_pptx()
    for path in (CURRENT_PPTX, PPTX, DRM_TILL_ACTUAL_PPTX, DRM_FULL_PREVIOUS_PPTX, DRM_YEARLY_COMPARISON_PPTX):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            assert "ppt/presentation.xml" in z.namelist()
    for path in (CURRENT_XLSX, FR_XLSX, XLSX):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
    for path in (CURRENT_PDF, FR_PDF, SMH_MATRIX_PDF):
        assert path.read_bytes().startswith(b"%PDF")
    print(f"Generated {CURRENT_XLSX}")
    print(f"Generated {CURRENT_PDF}")
    print(f"Generated {FR_XLSX}")
    print(f"Generated {FR_PDF}")
    print(f"Generated {SMH_MATRIX_PDF}")
    print(f"Generated {XLSX}")
    print(f"Generated {CURRENT_PPTX}")
    print(f"Generated {PPTX}")
    print(f"Generated {DRM_TILL_ACTUAL_PPTX}")
    print(f"Generated {DRM_FULL_PREVIOUS_PPTX}")
    print(f"Generated {DRM_YEARLY_COMPARISON_PPTX}")


if __name__ == "__main__":
    build()
