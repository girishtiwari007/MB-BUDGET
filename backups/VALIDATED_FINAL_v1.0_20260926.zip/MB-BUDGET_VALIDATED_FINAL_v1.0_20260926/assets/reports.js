const DATA = window.REPORTS_DATA || {
  months: [],
  years: [],
  monthly: { pu: {}, demand: {}, dept: {} },
  budget: { pu: {}, demand: {} },
};
const META = window.CURRENT_PAYLOAD_META || {};

const SHEETJS_SRC = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
const colors = ["#1f4e79", "#b94b4b", "#78a641", "#735999", "#126a66", "#d19a2a"];
const IMPORTANT_PU_CODES = new Set(["27", "28", "30", "32", "60"]);
const REPORTS = {
  pu_month: {
    label: "PRIMARY UNIT MONTH-WISE",
    title: "PRIMARY UNIT MONTH-WISE EXPENDITURE",
    scope: "pu",
    metric: "ae_monthwise",
    chart: "grouped",
    note: "Four-year monthly comparison for individual Primary Unit heads.",
  },
  demand_budget: {
    label: "DEMAND / SUB MAJOR HEAD",
    title: "DEMAND / SUB MAJOR HEAD BUDGET AND ACTUAL EXPENDITURE",
    scope: "demand",
    metric: "bp_vs_ae",
    chart: "bar",
    note: "Demand / Sub Major Head budget, Budget Proportion and Actual Expenditure comparison. Older demand files provide annual/stage values, not month-wise breakup.",
  },
  dept_current: {
    label: "DEPARTMENT",
    title: "DEPARTMENT CURRENT-YEAR MONTH-WISE EXPENDITURE",
    scope: "dept",
    metric: "ae_monthwise",
    chart: "heatmap",
    note: "Department-wise month view is available for the current detailed actual file.",
  },
  yearly: {
    label: "YEARLY OVERVIEW",
    title: "YEARLY PRIMARY UNIT EXPENDITURE OVERVIEW",
    scope: "yearly",
    metric: "year_total",
    chart: "bar",
    note: "All Primary Unit yearly actual expenditure based on available month-wise Primary Unit files.",
  },
  bp_ae: {
    label: "BUDGET PROPORTION VS ACTUAL EXPENDITURE",
    title: "BUDGET PROPORTION VS ACTUAL EXPENDITURE UTILIZATION",
    scope: "pu",
    metric: "bp_vs_ae",
    chart: "bar",
    note: "Budget Proportion versus Actual Expenditure for the selected Primary Unit or Demand / Sub Major Head.",
  },
};

const state = { report: "pu_month", scope: "pu", item: "", metric: "ae_monthwise", month: "APR", chart: "grouped", importantPuOnly: false, basis: "completed", yearFilter: ["all"] };
const $ = (id) => document.getElementById(id);
const PERIOD_MONTHS = ["APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR"];
function periodFromLabel(label, fallbackLabel) {
  const text = String(label || fallbackLabel || "AUG 2026").trim().toUpperCase();
  const month = (text.match(/([A-Z]{3})\s+20\d{2}/) || [null, text.slice(0, 3)])[1];
  const count = Math.max(1, PERIOD_MONTHS.indexOf(month) + 1 || 4);
  return { label: text, count, index: count - 1 };
}
const COMPLETED_PERIOD = periodFromLabel(META.completedMonth, "AUG 2026");
const RUNNING_PERIOD = periodFromLabel(META.runningMonth, "SEP 2026");
const BASIS_SOURCE = META.basisSource || "auto-sensed from uploaded file";

function dataTimestampText(value) {
  if (!value) return new Date().toLocaleString("en-IN");
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-IN");
}

function dataStampText() {
  const uploadStamp = DATA.statusAsOn || DATA.generatedAt;
  return `Data as on: ${dataTimestampText(uploadStamp)} | Last upload: ${dataTimestampText(uploadStamp)} | GUI basis: Completed Actual Month ${COMPLETED_PERIOD.label} (${String(COMPLETED_PERIOD.count).padStart(2, "0")}); running ${RUNNING_PERIOD.label} | Source: ${BASIS_SOURCE}`;
}

function dataStampHtml() {
  const parts = dataStampText().split(" | ");
  return parts.map((part) => {
    const [label, ...rest] = part.split(": ");
    return `<strong>${esc(label)}:</strong> ${esc(rest.join(": "))}`;
  }).join(" | ");
}

function refreshDataStamp() {
  const stamp = $("reportDataStamp");
  if (stamp) stamp.innerHTML = dataStampHtml();
}

function fmt(value, decimals = 0) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "N/A";
  return Number(value).toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

function moneyCell(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "N/A";
  return `<span class="dual-money"><span class="thousand">${esc(fmt(value))}</span><span class="crore">${esc(fmt(Number(value) / 10000, 2))} Cr</span></span>`;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}

function allYears() {
  return (DATA.years || []).map((year) => year.fy);
}

function years() {
  const available = allYears();
  const selected = Array.isArray(state.yearFilter) ? state.yearFilter.filter((year) => available.includes(year)) : [];
  return selected.length ? selected : available;
}

function latestYear() {
  return allYears().at(-1);
}

function selectedLatestYear() {
  return years().at(-1) || latestYear();
}

function activeMonthLimit(fy) {
  if (fy !== latestYear()) return DATA.months.length;
  return state.basis === "completed" ? COMPLETED_PERIOD.count : RUNNING_PERIOD.count;
}

function itemsFor(scope) {
  if (scope === "yearly") return ["All"];
  const items = Object.keys(DATA.monthly?.[scope] || {}).filter((item) => item.toUpperCase() !== "TOTAL" && !isDemandSuspenseName(item)).sort();
  return scope === "pu" && state.importantPuOnly ? items.filter(isImportantPuName) : items;
}

function series(scope, item) {
  if (scope === "yearly") {
    const out = {};
    const puRows = Object.entries(DATA.monthly.pu || {}).filter(([name]) => !state.importantPuOnly || isImportantPuName(name)).map(([, row]) => row);
    for (const fy of years()) {
      out[fy] = DATA.months.map((_, index) =>
        puRows.reduce((sum, row) => sum + Number(row?.[fy]?.[index] || 0), 0),
      );
    }
    return out;
  }
  return DATA.monthly?.[scope]?.[item] || {};
}

function puCodeFromName(name) {
  const match = String(name || "").match(/PU\s*-\s*([0-9A-Z]+)/i);
  return match ? match[1].toUpperCase() : "";
}

function isImportantPuName(name) {
  return IMPORTANT_PU_CODES.has(puCodeFromName(name));
}

function isDemandSuspenseName(name) {
  const text = String(name || "").toUpperCase();
  return /\b12N\b/.test(text) || /\b10N\b/.test(text) || text.includes("SUSPENSE");
}

function demandSuspenseItems(source) {
  return Object.keys(source || {}).filter((item) => item.toUpperCase() !== "TOTAL" && isDemandSuspenseName(item)).sort();
}

function importantPuNames() {
  return Object.keys(DATA.monthly?.pu || {})
    .filter((name) => name.toUpperCase() !== "TOTAL" && isImportantPuName(name))
    .sort((a, b) => Number(puCodeFromName(a)) - Number(puCodeFromName(b)));
}

function selectedImportantPuNames() {
  if (state.scope === "pu" && state.item && isImportantPuName(state.item)) return [state.item];
  return importantPuNames();
}

function hasSeriesYear(s, fy) {
  return Array.isArray(s?.[fy]);
}

function monthValue(s, fy, index) {
  if (index >= activeMonthLimit(fy)) return null;
  return hasSeriesYear(s, fy) ? Number(s[fy][index] || 0) : null;
}

function total(arr, limit = null) {
  if (!Array.isArray(arr)) return null;
  return arr.slice(0, limit || arr.length).reduce((sum, value) => sum + Number(value || 0), 0);
}

function periodTotal(s, fy) {
  return total(s?.[fy], activeMonthLimit(fy));
}

function budgetValues(scope, item, year) {
  const b = budget(scope, item)?.[year] || null;
  const s = series(scope, item);
  const oba = b ? Number(b.oba || 0) : null;
  const sourceBp = b && b.bp !== undefined && b.bp !== null && b.bp !== "" ? Number(b.bp || 0) : null;
  const bp = sourceBp !== null ? sourceBp : year === latestYear() && oba !== null ? oba / 12 * activeMonthLimit(year) : null;
  const ae = year === latestYear() ? periodTotal(s, year) : b ? Number(b.ae || periodTotal(s, year) || 0) : periodTotal(s, year);
  return { oba, bp, ae };
}

function budget(scope, item) {
  return DATA.budget?.[scope]?.[item] || {};
}

function setOptions(select, options, value) {
  select.innerHTML = options.map((option) => `<option value="${esc(option)}" ${option === value ? "selected" : ""}>${esc(optionLabel(option))}</option>`).join("");
  if (!options.includes(value)) select.value = options[0] || "";
}

function setYearOptions() {
  const host = $("yearChecks");
  if (!host) return;
  const available = allYears();
  const selected = Array.isArray(state.yearFilter) && state.yearFilter.length ? state.yearFilter : ["all"];
  const allSelected = selected.includes("all") || selected.length === available.length;
  host.innerHTML = [
    `<label class="check-all"><input type="checkbox" data-year-filter="all" ${allSelected ? "checked" : ""}> All financial years</label>`,
    ...available.map((year) => `<label><input type="checkbox" data-year-filter="${esc(year)}" ${allSelected || selected.includes(year) ? "checked" : ""}> ${esc(year)}</label>`),
  ].join("");
  const label = $("yearPickerLabel");
  if (label) label.textContent = selectedYearsText();
}

function readSelectedYears() {
  const host = $("yearChecks");
  if (!host) return ["all"];
  const available = allYears();
  const picked = Array.from(host.querySelectorAll('input[data-year-filter]:checked')).map((input) => input.dataset.yearFilter);
  if (!picked.length || picked.includes("all") || picked.length === available.length) return ["all"];
  return picked.filter((year) => allYears().includes(year));
}

function selectedYearsText() {
  const selected = years();
  return selected.length === allYears().length ? "All years" : selected.join(", ");
}

function optionLabel(option) {
  const fixed = {
    pu: "PRIMARY UNIT",
    demand: "DEMAND / SUB MAJOR HEAD",
    dept: "DEPARTMENT",
    yearly: "YEARLY OVERVIEW",
    ae_monthwise: "MONTH-WISE ACTUAL EXPENDITURE",
    specific_month: "SPECIFIC MONTH ACTUAL EXPENDITURE",
    bp_vs_ae: "BUDGET PROPORTION VS ACTUAL EXPENDITURE",
    oba_vs_ae: "ORIGINAL BUDGET ALLOTMENT VS ACTUAL EXPENDITURE",
    year_total: "YEAR TOTAL",
    grouped: "GROUPED BAR CHART",
    bar: "BAR CHART",
    line_markers: "MULTI-SERIES LINE CHART WITH MARKERS",
    pie: "PIE CHART",
    heatmap: "HEATMAP",
    "11 - SnT": "11 - SIGNAL AND TELECOMMUNICATION",
    "03 - GEN. ADMN.": "03 - GENERAL ADMINISTRATION",
  }[option];
  if (fixed) return fixed;
  return String(option)
    .replace(/\bSnT\b/g, "SIGNAL AND TELECOMMUNICATION")
    .replace(/\bGEN\. ADMN\.\b/g, "GENERAL ADMINISTRATION");
}

function setControlVisibility() {
  const chartAllowed = state.report !== "demand_budget" || state.metric !== "ae_monthwise";
  const importantAllowed = state.scope === "pu" || state.report === "yearly";
  $("scopeWrap").classList.toggle("hide", !["bp_ae"].includes(state.report));
  $("metricWrap").classList.toggle("hide", !["pu_month", "demand_budget", "bp_ae"].includes(state.report));
  $("itemWrap").classList.toggle("hide", state.scope === "yearly");
  $("monthWrap").classList.toggle("hide", state.metric !== "specific_month");
  $("chartWrap").classList.toggle("hide", !chartAllowed);
  $("yearWrap").classList.toggle("hide", false);
  $("importantPuWrap").classList.toggle("hide", !importantAllowed);
}

function reportMenuHtml() {
  return `<label class="report-selector-label" for="reportSelector">Report / Analysis<select id="reportSelector">${Object.entries(REPORTS).map(([key, report]) =>
    `<option value="${esc(key)}" ${state.report === key ? "selected" : ""}>${esc(report.label)}</option>`,
  ).join("")}</select></label>`;
}

function applyReportDefaults(reportKey) {
  const report = REPORTS[reportKey];
  state.report = reportKey;
  state.scope = report.scope;
  state.metric = report.metric;
  state.chart = report.chart;
  state.item = "";
  state.yearFilter = ["all"];
}

function setup() {
  $("reportMenu").innerHTML = reportMenuHtml();
  $("reportMenu").addEventListener("change", (event) => {
    const selector = event.target.closest("#reportSelector");
    if (!selector) return;
    applyReportDefaults(selector.value);
    render();
  });
  setOptions($("scope"), ["pu", "demand"], state.scope);
  setOptions($("metric"), ["ae_monthwise", "specific_month", "bp_vs_ae", "oba_vs_ae", "year_total"], state.metric);
  setOptions($("month"), DATA.months, state.month);
  setOptions($("chart"), ["grouped", "bar", "pie", "heatmap"], state.chart);
  setYearOptions();
  setBasisLabels();
  $("basis").value = state.basis;
  ["scope", "item", "metric", "month", "chart", "basis"].forEach((id) =>
    $(id).addEventListener("change", (event) => {
      state[id] = event.target.value;
      if (id === "scope") state.item = "";
      render();
    }),
  );
  $("yearChecks")?.addEventListener("change", (event) => {
    const input = event.target.closest("input[data-year-filter]");
    if (!input) return;
    const available = allYears();
    if (input.dataset.yearFilter === "all") {
      state.yearFilter = input.checked ? ["all"] : [];
    } else {
      const current = new Set(years());
      if (input.checked) current.add(input.dataset.yearFilter);
      else current.delete(input.dataset.yearFilter);
      state.yearFilter = current.size === available.length ? ["all"] : [...current].filter((year) => available.includes(year));
    }
    render();
  });
  $("importantPuOnly").addEventListener("change", (event) => {
    state.importantPuOnly = event.target.checked;
    state.item = "";
    render();
  });
  $("exportReportExcel")?.addEventListener("click", exportReportExcel);
  $("exportReportPdf")?.addEventListener("click", exportReportPdf);
  render();
}

function syncControls() {
  $("reportMenu").innerHTML = reportMenuHtml();
  setOptions($("scope"), ["pu", "demand"], state.scope);
  setOptions($("metric"), metricOptions(), state.metric);
  setOptions($("chart"), chartOptions(), state.chart);
  setOptions($("month"), DATA.months, state.month);
  setYearOptions();
  setBasisLabels();
  $("basis").value = state.basis;
  const options = itemsFor(state.scope);
  if (!state.item || !options.includes(state.item)) state.item = options[0] || "";
  setOptions($("item"), options, state.item);
  $("importantPuOnly").checked = state.importantPuOnly;
  setControlVisibility();
}

function setBasisLabels() {
  const basis = $("basis");
  if (!basis) return;
  const completed = basis.querySelector('option[value="completed"]');
  const tilldate = basis.querySelector('option[value="tilldate"]');
  if (completed) completed.textContent = `Completed Actual Month - ${COMPLETED_PERIOD.label} (${String(COMPLETED_PERIOD.count).padStart(2, "0")})`;
  if (tilldate) tilldate.textContent = `Till Date / Running Month - ${RUNNING_PERIOD.label} (${String(RUNNING_PERIOD.count).padStart(2, "0")})`;
}

function metricOptions() {
  if (state.report === "pu_month") return ["ae_monthwise", "specific_month", "year_total"];
  if (state.report === "demand_budget") return ["bp_vs_ae", "oba_vs_ae", "year_total"];
  if (state.report === "bp_ae") return ["bp_vs_ae", "oba_vs_ae"];
  return ["ae_monthwise", "specific_month", "year_total"];
}

function chartOptions() {
  if (state.report === "dept_current") return ["heatmap", "bar", "line_markers"];
  if (state.report === "yearly" || state.report === "bp_ae" || state.report === "demand_budget") return ["bar", "line_markers", "pie"];
  return ["grouped", "line_markers", "bar", "pie", "heatmap"];
}

function metricLabel() {
  return {
    ae_monthwise: "MONTH-WISE ACTUAL EXPENDITURE",
    specific_month: `${state.month} ACTUAL EXPENDITURE`,
    bp_vs_ae: "BUDGET PROPORTION VS ACTUAL EXPENDITURE",
    oba_vs_ae: "ORIGINAL BUDGET ALLOTMENT VS ACTUAL EXPENDITURE",
    year_total: "YEAR TOTAL",
  }[state.metric] || state.metric;
}

function valuesForCurrent() {
  const fy = years();
  const s = series(state.scope, state.item);
  if (state.metric === "specific_month") {
    const index = DATA.months.indexOf(state.month);
    return fy.map((year) => ({ label: year, value: monthValue(s, year, index) }));
  }
  if (state.metric === "year_total") {
    return fy.map((year) => ({ label: year, value: periodTotal(s, year) }));
  }
  if (state.metric === "bp_vs_ae" || state.metric === "oba_vs_ae") {
    return fy.flatMap((year) => [
      { label: `${year} ${state.metric === "bp_vs_ae" ? "BUDGET PROPORTION" : "ORIGINAL BUDGET ALLOTMENT"}`, value: state.metric === "bp_vs_ae" ? budgetValues(state.scope, state.item, year).bp : budgetValues(state.scope, state.item, year).oba },
      { label: `${year} ACTUAL EXPENDITURE`, value: budgetValues(state.scope, state.item, year).ae },
    ]);
  }
  return fy.map((year) => ({ label: year, value: periodTotal(s, year) }));
}

function summaryHtml() {
  const vals = valuesForCurrent().filter((item) => item.value !== null);
  const maxItem = vals.reduce((best, item) => !best || Math.abs(item.value) > Math.abs(best.value) ? item : best, null);
  const latestSelectedYear = selectedLatestYear();
  const s = series(state.scope, state.item);
  const latestTotal = periodTotal(s, latestSelectedYear);
  const availableYears = years().filter((year) => hasSeriesYear(s, year)).length || vals.filter((item) => item.value !== null).length;
  return `<div class="summary">
    <div class="card"><span>Report Mode</span><strong>${esc(REPORTS[state.report].label)}</strong></div>
    <div class="card"><span>Selected Item</span><strong>${esc(state.scope === "yearly" ? (state.importantPuOnly ? "IMPORTANT PRIMARY UNITS" : "ALL PRIMARY UNIT") : optionLabel(state.item || "All"))}</strong></div>
    <div class="card"><span>Year Selection</span><strong>${esc(selectedYearsText())}</strong></div>
    <div class="card"><span>Metric</span><strong>${esc(metricLabel())}</strong></div>
    <div class="card"><span>${esc(latestSelectedYear)} Total</span><strong>${moneyCell(latestTotal)}</strong></div>
    <div class="card"><span>Highest Value</span><strong>${moneyCell(maxItem?.value)}</strong></div>
    <div class="card"><span>Years Available</span><strong>${availableYears}</strong></div>
  </div>`;
}

function availabilityNote() {
  const s = series(state.scope, state.item);
  const missing = years().filter((year) => !hasSeriesYear(s, year));
  if (!missing.length || state.metric === "bp_vs_ae" || state.metric === "oba_vs_ae") return "";
  return `<div class="warn">Month-wise data is not available for ${esc(missing.join(", "))} in this view. The page shows N/A instead of treating missing data as zero.</div>`;
}

function insightHtml() {
  const vals = valuesForCurrent().filter((item) => item.value !== null);
  const top = [...vals].sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 3);
  return `<section class="insights"><div class="section-head"><h2>QUICK INSIGHTS</h2><span>${remarksText()}</span></div>${top.map((item) => `<div><strong>${esc(item.label)}</strong><span>${moneyCell(item.value)}</span></div>`).join("") || "<p>No values available for the selected report.</p>"}</section>`;
}

function attentionTone(value, high = 110, watch = 90) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "neutral";
  const n = Number(value);
  if (n < 0 || n >= high) return "red";
  if (n >= watch) return "amber";
  return "green";
}

function attentionFindings() {
  const fy = selectedLatestYear();
  const selected = state.scope === "yearly" ? "" : state.item;
  const scope = state.scope === "yearly" ? "pu" : state.scope;
  const findings = [];
  if (["pu", "demand"].includes(scope) && selected) {
    const { oba, bp, ae } = budgetValues(scope, selected, fy);
    const bpUse = bp ? ae / bp * 100 : null;
    const obaUse = oba ? ae / oba * 100 : null;
    const remaining = oba !== null && ae !== null ? oba - ae : null;
    findings.push({
      tone: attentionTone(bpUse, 110, 90),
      title: "% BP Utilized",
      text: bpUse === null ? "BP not available for selected item." : `${fmt(bpUse, 1)}% of Budget Proportion used; AE ${moneyCell(ae)} against BP ${moneyCell(bp)}.`,
    });
    findings.push({
      tone: attentionTone(obaUse, 70, 45),
      title: "% OBA Utilized",
      text: obaUse === null ? "OBA not available for selected item." : `${fmt(obaUse, 1)}% of OBA used; remaining budget ${moneyCell(remaining)}.`,
    });
  }
  if (state.metric === "ae_monthwise" || state.metric === "specific_month" || state.report === "yearly") {
    const vals = valuesForCurrent().filter((item) => item.value !== null);
    const largest = [...vals].sort((a, b) => Math.abs(b.value) - Math.abs(a.value))[0];
    if (largest) {
      findings.push({
        tone: isImportantPuName(largest.label) ? "amber" : "green",
        title: "Highest Actual Driver",
        text: `${esc(largest.label)} is the largest visible value at ${moneyCell(largest.value)} for the selected view.`,
      });
    }
  }
  if (state.importantPuOnly || (state.scope === "pu" && selectedImportantPuNames().includes(selected))) {
    const names = selectedImportantPuNames();
    const rows = names.map((name) => {
      const { bp, ae } = budgetValues("pu", name, fy);
      return { name, bp, ae, bpUse: bp ? ae / bp * 100 : null };
    }).filter((row) => row.ae !== null);
    const pressure = rows.filter((row) => row.bpUse !== null && row.bpUse >= 100).length;
    findings.push({
      tone: pressure ? "amber" : "green",
      title: "Important PU Watch",
      text: `${pressure} of ${rows.length || names.length} important PU row(s) are at or above BP. Keep PU 27, 28, 30, 32 and 60 separately reviewed.`,
    });
  }
  const suspense = demandSuspenseItems(DATA.monthly?.demand || {});
  if (suspense.length) {
    findings.push({
      tone: "red",
      title: "Demand 12N / 10N Separate",
      text: "Suspense/negative demand is excluded from normal demand totals and remains in the separate verification table.",
    });
  }
  return findings.slice(0, 5);
}

function attentionAnalysisHtml() {
  const findings = attentionFindings();
  return `<section class="ai-analysis"><div class="section-head"><h2>AI-STYLE ATTENTION ANALYSIS</h2><span>Rule-based finance checks from current filters</span></div>${findings.map((item) => `<article class="${item.tone}"><strong>${esc(item.title)}</strong><span>${item.text}</span></article>`).join("") || "<p>No attention points for current selection.</p>"}</section>`;
}

function groupedChart() {
  const fy = years();
  const s = series(state.scope, state.item);
  const max = Math.max(...fy.flatMap((year) => DATA.months.map((_, index) => Math.abs(monthValue(s, year, index) || 0))), 1);
  return `<section class="chart"><div class="section-head"><h2>MONTH-WISE EXPENDITURE</h2><span>${remarksText()}</span></div><div class="month-grid">${DATA.months.map((month, index) => `<div class="month-group"><div class="month-bars">${fy.map((year, colorIndex) => {
    const value = monthValue(s, year, index);
    return `<div class="vbar" title="${esc(year)} ${month}: ${fmt(value)}" style="height:${value === null ? 0 : Math.abs(value) / max * 100}%;background:${colors[colorIndex % colors.length]}"></div>`;
  }).join("")}</div><div class="month-label">${month}</div></div>`).join("")}</div>${legend(fy)}</section>`;
}

function barChart() {
  const vals = valuesForCurrent();
  const max = Math.max(...vals.map((item) => Math.abs(item.value || 0)), 1);
  return `<section class="chart"><div class="section-head"><h2>${esc(metricLabel())}</h2><span>${remarksText()}</span></div>${vals.map((item, index) => `<div class="bar-row ${isImportantPuName(item.label) ? "important-pu" : ""}"><strong>${esc(item.label)}</strong><div class="track"><div class="fill y${index % 4 + 1}" style="width:${item.value === null ? 0 : Math.abs(item.value) / max * 100}%"></div></div><span>${moneyCell(item.value)}</span></div>`).join("")}</section>`;
}

function pieChart() {
  const vals = valuesForCurrent().map((item) => ({ ...item, abs: Math.abs(item.value || 0) })).filter((item) => item.value !== null && item.abs > 0);
  const sum = vals.reduce((found, item) => found + item.abs, 0) || 1;
  let cursor = 0;
  const stops = vals.map((item, index) => {
    const start = cursor;
    cursor += item.abs / sum * 100;
    return `${colors[index % colors.length]} ${start}% ${cursor}%`;
  }).join(",");
  return `<section class="chart"><div class="section-head"><h2>SHARE VIEW</h2><span>${remarksText()}</span></div><div class="pie-wrap"><div class="pie" style="background:conic-gradient(${stops || "#edf4f8 0 100%"})"></div><div class="pie-values">${vals.map((item, index) => `<div class="legend"><span style="background:${colors[index % colors.length]}"></span>${esc(item.label)}: ${moneyCell(item.value)} (${fmt(item.abs / sum * 100, 1)}%)</div>`).join("") || "No available values for pie chart."}</div></div></section>`;
}

function chartMarkerTone(value, seriesMax) {
  if (!seriesMax) return "normal";
  const pct = Math.abs(Number(value || 0)) / seriesMax * 100;
  if (pct >= 90) return "high";
  if (pct >= 65) return "watch";
  return "normal";
}

function lineMarkerSeries() {
  const fy = years();
  if (state.metric === "ae_monthwise" || (state.report === "dept_current" && state.metric === "ae_monthwise")) {
    const s = series(state.scope, state.item);
    return {
      title: "MONTH-WISE ACTUAL EXPENDITURE TREND",
      xLabels: DATA.months,
      series: fy.map((year, index) => ({
        name: year,
        color: colors[index % colors.length],
        values: DATA.months.map((_, monthIndex) => monthValue(s, year, monthIndex)),
      })),
    };
  }
  if (state.metric === "bp_vs_ae" || state.metric === "oba_vs_ae") {
    const primaryLabel = state.metric === "bp_vs_ae" ? "Budget Proportion" : "OBA / RG";
    return {
      title: `${primaryLabel.toUpperCase()} VS ACTUAL EXPENDITURE`,
      xLabels: fy,
      series: [
        {
          name: primaryLabel,
          color: colors[0],
          values: fy.map((year) => state.metric === "bp_vs_ae" ? budgetValues(state.scope, state.item, year).bp : budgetValues(state.scope, state.item, year).oba),
        },
        {
          name: "Actual Expenditure",
          color: colors[1],
          values: fy.map((year) => budgetValues(state.scope, state.item, year).ae),
        },
      ],
    };
  }
  if (state.metric === "specific_month") {
    const index = DATA.months.indexOf(state.month);
    const s = series(state.scope, state.item);
    return {
      title: `${state.month} ACTUAL EXPENDITURE YEAR TREND`,
      xLabels: fy,
      series: [{
        name: `${state.month} Actual`,
        color: colors[0],
        values: fy.map((year) => monthValue(s, year, index)),
      }],
    };
  }
  const vals = valuesForCurrent().filter((item) => item.value !== null);
  return {
    title: `${metricLabel()} TREND`,
    xLabels: vals.map((item) => item.label),
    series: [{
      name: metricLabel(),
      color: colors[0],
      values: vals.map((item) => item.value),
    }],
  };
}

function svgText(text, x, y, cls = "", extra = "") {
  return `<text x="${x}" y="${y}" class="${cls}" ${extra}>${esc(text)}</text>`;
}

function lineMarkersChart() {
  const chart = lineMarkerSeries();
  const width = 980;
  const height = 360;
  const left = 76;
  const right = 26;
  const top = 30;
  const bottom = 76;
  const plotW = width - left - right;
  const plotH = height - top - bottom;
  const allValues = chart.series.flatMap((s) => s.values).filter((value) => value !== null && value !== undefined && !Number.isNaN(Number(value))).map(Number);
  const min = Math.min(0, ...allValues);
  const max = Math.max(1, ...allValues);
  const span = max - min || 1;
  const xFor = (index) => left + (chart.xLabels.length <= 1 ? plotW / 2 : index / (chart.xLabels.length - 1) * plotW);
  const yFor = (value) => top + (max - Number(value || 0)) / span * plotH;
  const ticks = [0, .25, .5, .75, 1].map((ratio) => min + span * ratio);
  const grid = ticks.map((value) => {
    const y = yFor(value);
    return `<line class="line-grid" x1="${left}" y1="${y}" x2="${width - right}" y2="${y}"></line>${svgText(fmt(value), left - 8, y + 4, "line-axis-label", 'text-anchor="end"')}`;
  }).join("");
  const xLabels = chart.xLabels.map((label, index) => {
    const x = xFor(index);
    const short = String(label).length > 14 ? `${String(label).slice(0, 13)}...` : label;
    return `${svgText(short, x, height - 42, "line-x-label", 'text-anchor="middle"')}<line class="line-tick" x1="${x}" y1="${top}" x2="${x}" y2="${height - bottom + 4}"></line>`;
  }).join("");
  const seriesMax = Math.max(1, ...allValues.map((value) => Math.abs(value)));
  const lines = chart.series.map((item) => {
    const points = item.values.map((value, index) => value === null || value === undefined || Number.isNaN(Number(value)) ? null : [xFor(index), yFor(value), value]).filter(Boolean);
    const d = points.map((point, index) => `${index ? "L" : "M"}${point[0].toFixed(1)},${point[1].toFixed(1)}`).join(" ");
    const markers = points.map((point) => `<g class="line-marker ${chartMarkerTone(point[2], seriesMax)}"><circle cx="${point[0].toFixed(1)}" cy="${point[1].toFixed(1)}" r="5"></circle><title>${esc(item.name)}: ${fmt(point[2])}</title></g>`).join("");
    return `<path class="line-path" d="${d}" style="stroke:${item.color}"></path>${markers}`;
  }).join("");
  return `<section class="chart line-chart-panel"><div class="section-head"><h2>${esc(chart.title)}</h2><span>${remarksText()}</span></div><div class="line-chart-wrap"><svg class="line-chart-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(chart.title)}">${grid}${xLabels}<line class="line-axis" x1="${left}" y1="${height - bottom}" x2="${width - right}" y2="${height - bottom}"></line><line class="line-axis" x1="${left}" y1="${top}" x2="${left}" y2="${height - bottom}"></line>${lines}</svg></div>${legend(chart.series.map((item) => item.name))}</section>`;
}

function heatmap() {
  const fy = years();
  const s = series(state.scope, state.item);
  const max = Math.max(...fy.flatMap((year) => DATA.months.map((_, index) => Math.abs(monthValue(s, year, index) || 0))), 1);
  return `<section class="chart"><div class="section-head"><h2>HEATMAP</h2><span>${remarksText()}</span></div><table class="heat"><thead><tr><th>FINANCIAL YEAR</th>${DATA.months.map((month) => `<th>${month}</th>`).join("")}<th>Total</th></tr></thead><tbody>${fy.map((year) => `<tr><td>${esc(year)}</td>${DATA.months.map((month, index) => {
    const value = monthValue(s, year, index);
    const cls = value === null ? "" : Math.abs(value) > max * .66 ? "veryhot" : Math.abs(value) > max * .33 ? "hot" : "";
    return `<td class="${cls}">${moneyCell(value)}</td>`;
  }).join("")}<td>${moneyCell(periodTotal(s, year))}</td></tr>`).join("")}</tbody></table></section>`;
}

function legend(labels) {
  return `<div class="legend">${labels.map((label, index) => `<div><span style="background:${colors[index % colors.length]}"></span>${esc(label)}</div>`).join("")}</div>`;
}

function tableHtml() {
  const fy = years();
  const s = series(state.scope, state.item);
  return `<section class="tablebox"><div class="section-head"><h2>DATA TABLE</h2><span>${remarksText()}</span></div><table class="data-table"><thead><tr><th>FINANCIAL YEAR</th>${DATA.months.map((month) => `<th>${month}</th>`).join("")}<th>Total</th></tr></thead><tbody>${fy.map((year) => `<tr><td>${esc(year)}</td>${DATA.months.map((month, index) => `<td>${moneyCell(monthValue(s, year, index))}</td>`).join("")}<td>${moneyCell(periodTotal(s, year))}</td></tr>`).join("")}</tbody></table></section>`;
}

function demandSuspenseNoteHtml() {
  if (state.scope !== "demand" && state.report !== "demand_budget") return "";
  const items = demandSuspenseItems(DATA.monthly?.demand || {});
  if (!items.length) return "";
  const latest = latestYear();
  const rows = items.map((item) => {
    const { oba, bp, ae } = budgetValues("demand", item, latest);
    return `<tr class="special-demand"><td>${esc(optionLabel(item))}</td><td>${esc(latest)}</td><td>${moneyCell(oba)}</td><td>${moneyCell(bp)}</td><td>${moneyCell(ae)}</td></tr>`;
  }).join("");
  return `<section class="special-demand-panel"><h2>Demand 12N / 10N - Separate Suspense Verification</h2><p>This suspense/negative demand is excluded from normal demand selectors, charts and appendix totals. It remains visible here for audit checking.</p><table><thead><tr><th>Demand</th><th>Year</th><th>OBA / RG</th><th>BP</th><th>AE</th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function importantYearlyBreakdownHtml() {
  if (!state.importantPuOnly || state.report !== "yearly") return "";
  const fy = years();
  const rows = importantPuNames().map((name) => {
    const s = series("pu", name);
    const values = fy.map((year) => periodTotal(s, year));
    const grandTotal = values.reduce((sum, value) => sum + Number(value || 0), 0);
    return `<tr class="important-row"><td>${esc(optionLabel(name))}</td>${values.map((value) => `<td>${moneyCell(value)}</td>`).join("")}<td>${moneyCell(grandTotal)}</td></tr>`;
  }).join("");
  return `<section class="tablebox focus-table"><div class="section-head"><h2>IMPORTANT PU YEAR-WISE BREAKUP</h2><span>PU 27, 28, 30, 32, 60 shown separately</span></div><table class="data-table"><thead><tr><th>PRIMARY UNIT</th>${fy.map((year) => `<th>${esc(year)}</th>`).join("")}<th>Total</th></tr></thead><tbody>${rows || `<tr><td colspan="${fy.length + 2}">No important PU data available.</td></tr>`}</tbody></table></section>`;
}

function importantBudgetBreakdownHtml() {
  if (!state.importantPuOnly || state.report !== "bp_ae" || state.scope !== "pu") return "";
  const fy = years();
  const names = selectedImportantPuNames();
  const rows = names.flatMap((name) => {
    const s = series("pu", name);
    const b = budget("pu", name);
    return fy.map((year) => {
      const { oba, bp, ae } = budgetValues("pu", name, year);
      const bpPercent = bp ? ae / bp * 100 : null;
      const obaPercent = oba ? ae / oba * 100 : null;
      return `<tr class="important-row"><td>${esc(optionLabel(name))}</td><td>${esc(year)}</td><td>${moneyCell(oba)}</td><td>${moneyCell(bp)}</td><td>${moneyCell(ae)}</td><td>${moneyCell(ae === null || bp === null ? null : ae - bp)}</td><td>${fmt(bpPercent, 1)}</td><td>${fmt(obaPercent, 1)}</td></tr>`;
    });
  }).join("");
  const scopeText = names.length === 1 ? "selected important PU" : "each important PU";
  return `<section class="tablebox focus-table"><div class="section-head"><h2>IMPORTANT PU UTILIZATION BREAKUP</h2><span>OBA, Budget Proportion and Actual Expenditure for ${scopeText}</span></div><table class="data-table"><thead><tr><th>PRIMARY UNIT</th><th>FINANCIAL YEAR</th><th>OBA</th><th>BP</th><th>AE</th><th>AE - BP</th><th>% BP Utilized</th><th>% OBA Utilized</th></tr></thead><tbody>${rows || `<tr><td colspan="8">No important PU budget data available.</td></tr>`}</tbody></table></section>`;
}

function importantModeNoteHtml() {
  if (!state.importantPuOnly || state.report !== "pu_month" || state.scope !== "pu") return "";
  return `<div class="warn">Important PU Only is active. The Primary Unit selector is limited to PU 27, 28, 30, 32 and 60.</div>`;
}

function importantBreakdownHtml() {
  return `${demandSuspenseNoteHtml()}${importantModeNoteHtml()}${importantYearlyBreakdownHtml()}${importantBudgetBreakdownHtml()}`;
}

function exportFileName(prefix, extension) {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `${prefix}_${stamp}.${extension}`;
}

function downloadHtmlFile(html, fileName, mimeType) {
  const blob = new Blob([html], { type: mimeType });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  URL.revokeObjectURL(link.href);
  link.remove();
}

function ensureSheetJS() {
  if (window.XLSX) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = SHEETJS_SRC;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Excel writer could not load. Please keep internet available for XLSX export."));
    document.head.appendChild(script);
  });
}

function sheetName(name, fallback = "Sheet") {
  const cleaned = String(name || fallback).replace(/[\\/?*[\]:]/g, " ").replace(/\s+/g, " ").trim();
  return (cleaned || fallback).slice(0, 31);
}

function columnLetter(index) {
  let text = "";
  for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) text = String.fromCharCode(65 + ((n - 1) % 26)) + text;
  return text;
}

function exportColumnWidth(rows, index) {
  const maxLength = rows.reduce((max, row) => Math.max(max, String(row?.[index] ?? "").length), 0);
  return Math.max(index < 2 ? 20 : 11, Math.min(index < 2 ? 42 : 22, maxLength + 2));
}

function appendAoaSheet(workbook, name, rows) {
  const sheet = XLSX.utils.aoa_to_sheet(rows);
  const colCount = Math.max(1, ...rows.map((row) => row.length));
  const lastCol = columnLetter(colCount - 1);
  const lastRow = Math.max(rows.length, 4);
  sheet["!cols"] = Array.from({ length: colCount }, (_, index) => ({ wch: exportColumnWidth(rows, index) }));
  sheet["!rows"] = rows.map((_, index) => ({ hpt: index === 0 ? 24 : index === 3 ? 21 : 18 }));
  sheet["!merges"] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: colCount - 1 } },
    { s: { r: 1, c: 0 }, e: { r: 1, c: colCount - 1 } },
    { s: { r: 2, c: 0 }, e: { r: 2, c: colCount - 1 } },
  ];
  sheet["!autofilter"] = { ref: `A4:${lastCol}${lastRow}` };
  sheet["!freeze"] = { xSplit: 0, ySplit: 4 };
  XLSX.utils.book_append_sheet(workbook, sheet, sheetName(name));
}

function selectedReportAoa() {
  const fy = years();
  const s = series(state.scope, state.item);
  return [
    [REPORTS[state.report].title],
    [`Selected: ${state.scope === "yearly" ? (state.importantPuOnly ? "Important Primary Units" : "All Primary Unit") : optionLabel(state.item || "All")}`],
    [`${dataStampText()}. ${remarksText()}. Metric: ${metricLabel()}`],
    ["Financial Year", ...DATA.months, "Total"],
    ...fy.map((year) => [year, ...DATA.months.map((_, index) => monthValue(s, year, index)), periodTotal(s, year)]),
  ];
}

function monthlySourceAoa(scope, title) {
  const items = Object.keys(DATA.monthly?.[scope] || {}).filter((item) => item.toUpperCase() !== "TOTAL" && !isDemandSuspenseName(item)).sort();
  return [
    [title],
    [remarksText()],
    ["Appendix follows portal source sequence for PPT verification."],
    ["Item", "Financial Year", ...DATA.months, "Total"],
    ...items.flatMap((item) => years().map((year) => {
      const arr = DATA.monthly?.[scope]?.[item]?.[year];
      return [optionLabel(item), year, ...DATA.months.map((_, index) => monthValue({ [year]: arr }, year, index)), total(arr, activeMonthLimit(year))];
    })),
  ];
}

function budgetSourceAoa(scope, title) {
  const items = Object.keys(DATA.budget?.[scope] || {}).filter((item) => item.toUpperCase() !== "TOTAL" && !isDemandSuspenseName(item)).sort();
  return [
    [title],
    [remarksText()],
    ["Appendix follows portal source sequence for PPT verification."],
    ["Item", "Financial Year", "OBA", "BP", "AE", "AE - BP", "% BP Utilized", "% OBA Utilized"],
    ...items.flatMap((item) => years().map((year) => {
      const { oba, bp, ae } = budgetValues(scope, item, year);
      return [optionLabel(item), year, oba ?? "", bp ?? "", ae ?? "", ae === null || bp === null ? "" : ae - bp, bp ? ae / bp * 100 : "", oba ? ae / oba * 100 : ""];
    })),
  ];
}

function importantBudgetAoa() {
  const names = selectedImportantPuNames();
  return [
    ["Important PU Utilization Breakup"],
    ["OBA, Budget Proportion and Actual Expenditure for selected important PUs"],
    [remarksText()],
    ["Primary Unit", "Financial Year", "OBA", "BP", "AE", "AE - BP", "% BP Utilized", "% OBA Utilized"],
    ...names.flatMap((name) => years().map((year) => {
      const { oba, bp, ae } = budgetValues("pu", name, year);
      return [optionLabel(name), year, oba ?? "", bp ?? "", ae ?? "", ae === null || bp === null ? "" : ae - bp, bp ? ae / bp * 100 : "", oba ? ae / oba * 100 : ""];
    })),
  ];
}

function reportExportStyles(mode) {
  return `<style>
    @page{size:A4 landscape;margin:8mm}
    body{font-family:Calibri,Arial,sans-serif;color:#17212b;margin:0;background:#fff}
    main{width:100%;margin:0 auto}
    h1{font-size:21px;text-align:center;margin:0 0 4px;color:#1f4e79}
    h2{font-size:15px;margin:0 0 5px;color:#1f4e79}
    h3{font-size:13px;margin:8px 0 4px;color:#1f4e79}
    .meta{font-size:11px;text-align:right;margin:0 0 8px;font-weight:700}
    .export-cover{min-height:180mm;display:grid;place-items:center;text-align:center;break-after:page;page-break-after:always;border:2px solid #1f4e79;padding:18mm;box-sizing:border-box}
    .export-cover h1{font-size:26px;margin:0 0 8px;color:#1f4e79}
    .cover-meta{font-size:13px;line-height:1.6;font-weight:700;color:#17212b}
    .cover-list{font-size:12px;line-height:1.5;color:#405060;margin-top:10px}
    .export-section{break-after:page;page-break-after:always;padding-top:1mm}
    .export-section:last-child{break-after:auto;page-break-after:auto}
    table{width:100%;border-collapse:collapse;font-size:9.3px;table-layout:auto}
    thead{display:table-header-group}
    tfoot{display:table-footer-group}
    tr{break-inside:avoid;page-break-inside:avoid}
    th,td{border:1px solid #9fb0bf;padding:3px 4px;vertical-align:middle;white-space:normal;overflow-wrap:anywhere}
    th{background:#1f4e79;color:#fff;text-align:center}
    td{text-align:right}
    td:first-child,th:first-child{text-align:left}
    tbody tr:nth-child(even) td{background:#e8f2f8}
    .important-row td,.important-pu td{background:#fff4cc;font-weight:700}
    .dual-money{display:flex;flex-direction:column;align-items:flex-end;line-height:1.08;font-family:"Times New Roman",Times,serif;font-variant-numeric:tabular-nums}
    .dual-money .thousand{font-size:12px;font-weight:700;font-family:"Times New Roman",Times,serif}
    .dual-money .crore{margin-top:1px;font-size:9.5px;font-family:"Times New Roman",Times,serif;color:#006f78;opacity:1}
    .card .dual-money,.bar-row .dual-money,.legend .dual-money,.insights .dual-money{display:inline-flex;vertical-align:middle}
    .summary,.report-layout{display:block}
    .card,.chart,.tablebox,.insights,.ai-analysis{border:1px solid #c8d6e2;margin:0 0 8px;padding:7px}
    .ai-analysis article{border-left:4px solid #607080;background:#f8fbfd;padding:6px 7px;margin:0 0 5px;font-size:10px}
    .ai-analysis article strong{display:block;color:#17212b}
    .ai-analysis article.red{border-left-color:#b42318;background:#fff5f5}
    .ai-analysis article.amber{border-left-color:#d19a2a;background:#fff9e5}
    .ai-analysis article.green{border-left-color:#126a66;background:#f5fbf7}
    .bar-row{display:grid;grid-template-columns:165px 1fr 105px;gap:8px;align-items:center;margin:5px 0;font-size:10px}
    .track{height:14px;background:#edf4f8;border:1px solid #dbe6ee}
    .fill{height:100%;background:#1f4e79}
    .month-grid,.pie-wrap,.legend,.toolbar,.report-menu,.actions{display:none!important}
    ${mode === "excel" ? ".export-cover{display:none}.export-section{page-break-after:auto}.chart{display:none}" : ""}
  </style>`;
}

function monthlySourceTable(scope, title) {
  const items = Object.keys(DATA.monthly?.[scope] || {}).filter((item) => item.toUpperCase() !== "TOTAL" && !isDemandSuspenseName(item)).sort();
  const rows = items.flatMap((item) => years().map((year) => {
    const arr = DATA.monthly?.[scope]?.[item]?.[year];
    return `<tr class="${isImportantPuName(item) ? "important-row" : ""}"><td>${esc(optionLabel(item))}</td><td>${esc(year)}</td>${DATA.months.map((_, index) => `<td>${moneyCell(monthValue({ [year]: arr }, year, index))}</td>`).join("")}<td>${moneyCell(total(arr, activeMonthLimit(year)))}</td></tr>`;
  })).join("");
  return `<section class="export-section"><h2>${esc(title)}</h2><table><thead><tr><th>ITEM</th><th>FINANCIAL YEAR</th>${DATA.months.map((month) => `<th>${esc(month)}</th>`).join("")}<th>Total</th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function budgetSourceTable(scope, title) {
  const items = Object.keys(DATA.budget?.[scope] || {}).filter((item) => item.toUpperCase() !== "TOTAL" && !isDemandSuspenseName(item)).sort();
  const rows = items.flatMap((item) => years().map((year) => {
    const { oba, bp, ae } = budgetValues(scope, item, year);
    return `<tr class="${isImportantPuName(item) ? "important-row" : ""}"><td>${esc(optionLabel(item))}</td><td>${esc(year)}</td><td>${moneyCell(oba)}</td><td>${moneyCell(bp)}</td><td>${moneyCell(ae)}</td><td>${moneyCell(ae === null || bp === null ? null : ae - bp)}</td><td>${fmt(bp ? ae / bp * 100 : null, 1)}</td><td>${fmt(oba ? ae / oba * 100 : null, 1)}</td></tr>`;
  })).join("");
  return `<section class="export-section"><h2>${esc(title)}</h2><table><thead><tr><th>ITEM</th><th>FINANCIAL YEAR</th><th>OBA</th><th>BP</th><th>AE</th><th>AE - BP</th><th>% BP Utilized</th><th>% OBA Utilized</th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function reportExportDocument(mode) {
  const report = REPORTS[state.report];
  const selectedView = `<section class="export-section"><h2>${esc(report.title)}</h2><p class="meta">${esc(dataStampText())}<br>${remarksText()}. ${esc(report.note)}</p>${summaryHtml()}${renderChart()}${tableHtml()}${importantBreakdownHtml()}</section>`;
  const appendices = [
    monthlySourceTable("pu", "Appendix A - Primary Unit Month-Wise Actual Expenditure"),
    monthlySourceTable("demand", "Appendix B - Demand / SMH Month-Wise Actual Expenditure"),
    monthlySourceTable("dept", "Appendix C - Department Month-Wise Actual Expenditure"),
    budgetSourceTable("pu", "Appendix D - Primary Unit Budget Proportion vs Actual Expenditure"),
    budgetSourceTable("demand", "Appendix E - Demand / SMH Budget Proportion vs Actual Expenditure"),
  ].join("");
  const generatedAt = new Date().toLocaleString("en-IN");
  const selectedText = state.scope === "yearly" ? (state.importantPuOnly ? "Important Primary Units" : "All Primary Unit") : optionLabel(state.item || "All");
  const cover = `<section class="export-cover"><div><h1>Advanced Report and Chart Analysis</h1><div class="cover-meta">Selected report: ${esc(report.label)}<br>Selection: ${esc(selectedText)}<br>${esc(dataStampText())}<br>${remarksText()}<br>Generated ${generatedAt}</div><div class="cover-list">Includes selected chart/table view and appendices for PU, Demand / SMH, Department and utilization source data.</div></div></section>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>Advanced Report and Chart Analysis Export</title>${reportExportStyles(mode)}</head><body><main>${cover}<h1>Advanced Report and Chart Analysis</h1><p class="meta">Selected report: ${esc(report.label)}. ${esc(dataStampText())}. Generated ${generatedAt}.</p>${selectedView}${appendices}</main></body></html>`;
}

async function exportReportExcel() {
  await ensureSheetJS();
  const workbook = XLSX.utils.book_new();
  workbook.Props = { Title: "Advanced Report and Chart Analysis", Subject: "PPT-ready budget report export", Author: "MB Budget Portal", CreatedDate: new Date() };
  appendAoaSheet(workbook, "Selected Report", selectedReportAoa());
  if (state.importantPuOnly && state.report === "bp_ae" && state.scope === "pu") appendAoaSheet(workbook, "Important PU Utilization", importantBudgetAoa());
  appendAoaSheet(workbook, "PU Month Wise", monthlySourceAoa("pu", "Primary Unit Month-Wise Actual Expenditure"));
  appendAoaSheet(workbook, "Demand Month Wise", monthlySourceAoa("demand", "Demand / SMH Month-Wise Actual Expenditure"));
  appendAoaSheet(workbook, "Dept Month Wise", monthlySourceAoa("dept", "Department Month-Wise Actual Expenditure"));
  appendAoaSheet(workbook, "PU Utilization", budgetSourceAoa("pu", "Primary Unit Budget Proportion vs Actual Expenditure"));
  appendAoaSheet(workbook, "Demand Utilization", budgetSourceAoa("demand", "Demand / SMH Budget Proportion vs Actual Expenditure"));
  XLSX.writeFile(workbook, exportFileName("Advanced_Report_Chart_Analysis", "xlsx"));
}

function exportReportPdf() {
  const win = window.open("", "_blank");
  if (!win) { window.alert("Please allow popups to generate PDF."); return; }
  win.document.open();
  win.document.write(reportExportDocument("pdf"));
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 350);
}

function remarksText() {
  return `Remarks - Figures in '000' (thousands). Years: ${selectedYearsText()}. ${state.basis === "completed" ? `GUI synced basis: completed actuals up to ${COMPLETED_PERIOD.label} with ${String(COMPLETED_PERIOD.count).padStart(2, "0")}-month BP calculation` : `Till-date basis: ${RUNNING_PERIOD.label} running month with ${String(RUNNING_PERIOD.count).padStart(2, "0")}-month BP calculation`}`;
}

function renderChart() {
  if (state.chart === "bar") return barChart();
  if (state.chart === "line_markers") return lineMarkersChart();
  if (state.chart === "pie") return pieChart();
  if (state.chart === "heatmap") return heatmap();
  return groupedChart();
}

function render() {
  syncControls();
  const report = REPORTS[state.report];
  $("reportTitle").textContent = report.title;
  refreshDataStamp();
  $("host").innerHTML = `<p class="note">${remarksText()}. ${esc(report.note)}</p>${availabilityNote()}${summaryHtml()}<div class="report-layout">${renderChart()}</div>${tableHtml()}${importantBreakdownHtml()}`;
}

document.addEventListener("DOMContentLoaded", setup);
